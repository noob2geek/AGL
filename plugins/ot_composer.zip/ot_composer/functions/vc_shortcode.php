<?php 
//Custom Heading
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Heading", 'otvcp-i10n'),
   "base"      => "heading",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(
      array(
         "type"      => "textarea_html",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Text", 'otvcp-i10n'),
         "param_name"=> "content",
         "value"     => "",
         "description" => __("Add Text", 'otvcp-i10n'),
      ),      
      array(
        "type" => "dropdown",
        "heading" => __('Text Align', 'otvcp-i10n'),
        "param_name" => "align",
        "value" => array( 
                     __('Select Align', 'otvcp-i10n') => '',  
                     __('left', 'otvcp-i10n') => 'left',
                     __('right', 'otvcp-i10n') => 'right',  
                     __('center', 'otvcp-i10n') => 'center',
                     __('justify', 'otvcp-i10n') => 'justify',                  
                    ),
        "description" => __("Section Overlay", 'otvcp-i10n'),      
      ),                  
    )));
}

//Custom Heading 2
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Heading 2", 'otvcp-i10n'),
   "base"      => "heading2",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Title", 'otvcp-i10n'),
         "param_name"=> "title",
         "value"     => "",
         "description" => __("Add title", 'otvcp-i10n'),
      ),    
      array(
         "type"      => "textarea_html",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Content", 'otvcp-i10n'),
         "param_name"=> "content",
         "value"     => "",
         "description" => __("Add content", 'otvcp-i10n'),
      ),      
      array(
        "type" => "dropdown",
        "heading" => __('Text Align', 'otvcp-i10n'),
        "param_name" => "align",
        "value" => array( 
                     __('Select Align', 'otvcp-i10n') => '',  
                     __('left', 'otvcp-i10n') => 'left',
                     __('right', 'otvcp-i10n') => 'right',  
                     __('center', 'otvcp-i10n') => 'center',
                     __('justify', 'otvcp-i10n') => 'justify',                  
                    ),
        "description" => __("Section Overlay", 'otvcp-i10n'),      
      ), 
      array(
        "type" => "dropdown",
        "heading" => __('Select Style Heading', 'otvcp-i10n'),
        "param_name" => "style",
        "value" => array(  
                     __('Style 1', 'otvcp-i10n') => 'style1',
                     __('Style 2', 'otvcp-i10n') => 'style2',
                     __('Style 3', 'otvcp-i10n') => 'style3',                   
                    ),
        "description" => __("Section Style", 'otvcp-i10n'),      
      ), 
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Extra class name", 'otvcp-i10n'),
         "param_name"=> "extra_class",
         "value"     => "",
         "description" => __("Style particular content element differently - add a class name and refer to it in custom CSS.", 'otvcp-i10n'),
      ),                   
    )));
}

// Commitment
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Commitment", 'otvcp-i10n'),
   "base"      => "commitment_box",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(       
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Description", 'otvcp-i10n'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Content right.", 'otvcp-i10n')
      ),
      array(
         "type" => "attach_image",
         "holder" => "div",
         "class" => "",
         "heading" => "background image",
         "param_name" => "image_url",
         "value" => "",
         "description" => __("Upload your background image.", 'otvcp-i10n')
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Extra class name", 'otvcp-i10n'),
         "param_name" => "extra_class",
         "value" => "",
         "description" => __("Add extra class name for custom style.", 'otvcp-i10n')
      ), 
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ),     
    )));
}

// Home Parallax Image
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Home Parallax", 'otvcp-i10n'),
   "base"      => "home_parallax",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'Content',
   "params"    => array(  
      array(
         "type" => "attach_images",
         "holder" => "div",
         "class" => "",
         "heading" => "background image",
         "param_name" => "bg_image",
         "value" => "",
         "description" => __("Upload your background image.", 'otvcp-i10n')
      ),  
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Title",
         "param_name" => "title",
         "value" => "",
         "description" => __("Add your title.", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "SubTitle",
         "param_name" => "stitle",
         "value" => "",
         "description" => __("Add your subtitle.", 'otvcp-i10n')
      ),
      // params group
      array(
          'type' => 'param_group',
          'value' => '',
          'heading' => 'Add your text slider(multiple field)',
          'param_name' => 'titles',
          // Note params is mapped inside param-group:
          'params' => array(
              array(
                  'type' => 'textfield',
                  "holder" => "div",
                  "class" => "",
                  'heading' => 'Typing text',
                  'param_name' => 'title',
                  "value" => "",
                  "description" => __("Add title text (multiple field)", 'otvcp-i10n')
              )
          )                
      ),           
      array(
        'type' => 'vc_link',
         "heading" => __("Link Button", 'otvcp-i10n'),
         "param_name" => "linkbox",         
         "description" => __("Add your link to button.", 'otvcp-i10n')
      ), 
	  array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Extra class name",
         "param_name" => "extra_class",
         "value" => "",
         "description" => __("Style particular content element differently - add a class name and refer to it in custom CSS.", 'otvcp-i10n')
      ),
    )));
}

// Home Parallax Image 2
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Home Parallax 2", 'otvcp-i10n'),
   "base"      => "home_parallax2",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'Content',
   "params"    => array(        
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Title",
         "param_name" => "title",
         "value" => "",
         "description" => __("Add your title.", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "SubTitle",
         "param_name" => "stitle",
         "value" => "",
         "description" => __("Add your subtitle.", 'otvcp-i10n')
      ),          
      array(
        'type' => 'vc_link',
         "heading" => __("Link Button", 'otvcp-i10n'),
         "param_name" => "linkbox",         
         "description" => __("Add your link to button.", 'otvcp-i10n')
      ),   
    )));
}

// Home HTML5 Video
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Home HTML5 Video", 'otvcp-i10n'),
   "base"      => "home_html5_video",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'Content',
   "params"    => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Title",
         "param_name" => "title",
         "value" => "",
         "description" => __("Add your title.", 'otvcp-i10n')
      ),    
      array(
         "type" => "attach_images",
         "holder" => "div",
         "class" => "",
         "heading" => "Thumbnail image",
         "param_name" => "thumbnail_image",
         "value" => "",
         "description" => __("Upload your thumbnail image.", 'otvcp-i10n')
      ),  
      array(
         "type" => "attach_images",
         "holder" => "div",
         "class" => "",
         "heading" => "Video background image",
         "param_name" => "bg_image",
         "value" => "",
         "description" => __("Upload your video background image.", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "MP4",
         "param_name" => "mp4",
         "value" => "",
         "description" => __("Add your link video.", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Webm",
         "param_name" => "webm",
         "value" => "",
         "description" => __("Add your link video.", 'otvcp-i10n')
      ),        
    )));
}

// Call To Action
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Call To Action", 'otvcp-i10n'),
   "base" => "cta_button",
   "class" => "",
   "category"  => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Title",
         "param_name" => "title",
         "value" => "",
         "description" => __("Add your title.", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "SubTitle",
         "param_name" => "stitle",
         "value" => "",
         "description" => __("Add your subtitle.", 'otvcp-i10n')
      ),
      array(
        'type' => 'vc_link',
         "heading" => __("Button Link", 'otvcp-i10n'),
         "param_name" => "btnlink",         
         "description" => __("Add link to Button.", 'otvcp-i10n')
      ),  
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Extra class name",
         "param_name" => "extra_class",
         "value" => "",
         "description" => __("Style particular content element differently - add a class name and refer to it in custom CSS.", 'otvcp-i10n')
      ),  
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ),     
    )));
}

// Call To Action 2 use on preview 3 
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Call To Action 2", 'otvcp-i10n'),
   "base" => "cta_button2",
   "class" => "",
   "category"  => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Title",
         "param_name" => "title",
         "value" => "",
         "description" => __("Add your title.", 'otvcp-i10n')
      ),
      array(
        'type' => 'vc_link',
         "heading" => __("Button Link", 'otvcp-i10n'),
         "param_name" => "btnlink",         
         "description" => __("Add link to Button.", 'otvcp-i10n')
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Extra class name",
         "param_name" => "extra_class",
         "value" => "",
         "description" => __("Style particular content element differently - add a class name and refer to it in custom CSS.", 'otvcp-i10n')
      ),   
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ),     
    )));
}

// Buttons
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Button", 'otvcp-i10n'),
   "base" => "button",
   "class" => "",
   "category"  => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(
      array(
        'type' => 'vc_link',
         "heading" => __("Button Link", 'otvcp-i10n'),
         "param_name" => "btnlink",         
         "description" => __("Add link to Button.", 'otvcp-i10n')
      ),  
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => "Select style.",
         "param_name" => "style",
         "value" => array(
                     __('Button border light', 'otvcp-i10n') => 1,
                     __('Button default color', 'otvcp-i10n') => 2,
                     __('Button simple', 'otvcp-i10n') => 3,                  
                    ),
         "description" => __("Select button style", 'otvcp-i10n')
      ),      
    )));
}

// Awards Gallery
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Awards", 'otvcp-i10n'),
   "base"      => "awards",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(
      array(
         "type"      => "attach_images",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Gallery Image", 'otvcp-i10n'),
         "param_name"=> "gallery",
         "value"     => "",
         "description" => __("Upload Gallery Image and add title, description for image", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number visible",
         "param_name" => "visible",
         "value" => "",
         "description" => __("Add Number visible images, default: 3", 'otvcp-i10n')
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Show navigation button?", 'otvcp-i10n'),
         "param_name" => "navigation",
         "value" => array(   
                     __('Yes', 'otvcp-i10n') => 'yes',
                     __('No', 'otvcp-i10n') => 'no',
                    ),
         "description" => __("Default is show navigation button.", 'otvcp-i10n')
      ),       
    )));
}

// Image Slider
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Image Slider", 'otvcp-i10n'),
   "base"      => "img_slider",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(
      array(
         "type"      => "attach_images",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Gallery Image", 'otvcp-i10n'),
         "param_name"=> "gallery",
         "value"     => "",
         "description" => __("Upload Gallery Image and add title, description for image", 'otvcp-i10n')
      ),      
    )));
}

// History Post
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT History TimeLine", 'otvcp-i10n'),
   "base" => "history_post",
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(      
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Per Page",
         "param_name" => "number",
         "value" => "",
         "description" => __("Add Number -1 for show all post.", 'otvcp-i10n')
      ),             
    )
    ));
}

// Careers Post
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Career Post", 'otvcp-i10n'),
   "base" => "career_post",
   'admin_enqueue_js'  => OTVCP_DIR . 'assets/javascripts/select2.min.js',
   'admin_enqueue_css' => OTVCP_DIR . 'assets/stylesheets/select2.css',
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(     
      array(
         "type"      => "select_category_career",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Select Categories", 'otvcp-i10n'),
         "param_name"=> "idcate_career",
         "value"     => "",
         "description" => __("Enter your career category.", 'otvcp-i10n'),
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Per Page",
         "param_name" => "number",
         "value" => "",
         "description" => __("Add Number -1 for show all post.", 'otvcp-i10n')
      ),             
    )
    ));
}

// Careers Post 2
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Career Post 2", 'otvcp-i10n'),
   "base" => "career_post2",
   'admin_enqueue_js'  => OTVCP_DIR . 'assets/javascripts/select2.min.js',
   'admin_enqueue_css' => OTVCP_DIR . 'assets/stylesheets/select2.css',
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(    
      array(
         "type"      => "select_category_career",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Select Categories", 'otvcp-i10n'),
         "param_name"=> "idcate_career",
         "value"     => "",
         "description" => __("Enter your career category.", 'otvcp-i10n'),
      ),  
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Per Page",
         "param_name" => "number",
         "value" => "",
         "description" => __("Add Number -1 for show all post.", 'otvcp-i10n')
      ),             
    )
    ));
}

if ( ! function_exists( 'is_plugin_active' ) ) {
  require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {     
  if ( function_exists( 'vc_add_shortcode_param' ) ) {
     vc_add_shortcode_param( 'select_category_career', 'select_param_career', OTVCP_DIR . 'assets/javascripts/select-field-career.js' );
  } elseif ( function_exists( 'add_shortcode_param' ) ) {
     add_shortcode_param( 'select_category_career', 'select_param_career', OTVCP_DIR . 'assets/javascripts/select-field-career.js' );
  }
}   

function select_param_career( $settings, $value ) {  
  $category_career = get_terms( 'category_career' );
  $cat_testimonials = array();
  foreach( $category_career as $category ) {
     if( $category ) {
        $cat_testimonials[] = sprintf('<option value="%s">%s</option>',
           esc_attr( $category->slug ),
           $category->name
        );
     }

  }

  return sprintf(
     '<input type="hidden" name="%s" value="%s" class="wpb-input-category_career wpb_vc_param_value wpb-textinput %s %s_field">
     <select class="select-category_career-post">
     %s
     </select>',
     esc_attr( $settings['param_name'] ),
     esc_attr( $value ),
     esc_attr( $settings['param_name'] ),
     esc_attr( $settings['type'] ),
     implode( '', $cat_testimonials )
  );
}

// Founder & Directors Post
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Founder & Directors", 'otvcp-i10n'),
   "base" => "founder_directors",
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(      
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Per Page",
         "param_name" => "number",
         "value" => "",
         "description" => __("Add Number -1 for show all post.", 'otvcp-i10n')
      ),             
    )
    ));
}

// Testimonial Slider
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Testimonial Silder", 'otvcp-i10n'),
   "base" => "testslide",
   'admin_enqueue_js'  => OTVCP_DIR . 'assets/javascripts/select2.min.js',
   'admin_enqueue_css' => OTVCP_DIR . 'assets/stylesheets/select2.css',
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type"      => "select_category_testimonials",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Select Categories", 'otvcp-i10n'),
         "param_name"=> "idcate_testimonials",
         "value"     => "",
         "description" => __("Enter your testimonials category.", 'otvcp-i10n'),
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Testimonial",
         "param_name" => "number",
         "value" => "",
         "description" => __("Add Number -1 for show all post.", 'otvcp-i10n')
      ),  
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => "Visible Testimonial",
         "param_name" => "visible",
         "value" => array(
                     __('Select Visible', 'otvcp-i10n') => '',
                     __('1 Column', 'otvcp-i10n') => '1',
                     __('2 Columns', 'otvcp-i10n') => '2',
                     __('3 Columns', 'otvcp-i10n') => '3', 
                     __('4 Columns', 'otvcp-i10n') => '4',                  
                    ),
         "description" => __("Description", 'otvcp-i10n')
      ),                  
    )
    ));
}

// Testimonial Slider 2
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Testimonial Silder 2", 'otvcp-i10n'),
   "base" => "testslide2",
   'admin_enqueue_js'  => OTVCP_DIR . 'assets/javascripts/select2.min.js',
   'admin_enqueue_css' => OTVCP_DIR . 'assets/stylesheets/select2.css',
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array( 
      array(
         "type"      => "select_category_testimonials",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Select Categories", 'otvcp-i10n'),
         "param_name"=> "idcate_testimonials",
         "value"     => "",
         "description" => __("Enter your testimonials category.", 'otvcp-i10n'),
      ),     
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Testimonial",
         "param_name" => "number",
         "value" => "",
         "description" => __("Add Number -1 for show all post.", 'otvcp-i10n')
      ),             
    )
    ));
}

// Testimonial Slider 3
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Testimonial Silder 3", 'otvcp-i10n'),
   "base" => "testslide3",
   'admin_enqueue_js'  => OTVCP_DIR . 'assets/javascripts/select2.min.js',
   'admin_enqueue_css' => OTVCP_DIR . 'assets/stylesheets/select2.css',
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array( 
      array(
         "type"      => "select_category_testimonials",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Select Categories", 'otvcp-i10n'),
         "param_name"=> "idcate_testimonials",
         "value"     => "",
         "description" => __("Enter your testimonials category.", 'otvcp-i10n'),
      ),     
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Testimonial",
         "param_name" => "number",
         "value" => "",
         "description" => __("Add Number -1 for show all post.", 'otvcp-i10n')
      ),             
    )
    ));
}

// Testimonial Grid
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Testimonial Grid", 'otvcp-i10n'),
   "base" => "testgrid",
   'admin_enqueue_js'  => OTVCP_DIR . 'assets/javascripts/select2.min.js',
   'admin_enqueue_css' => OTVCP_DIR . 'assets/stylesheets/select2.css',
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array( 
      array(
         "type"      => "select_category_testimonials",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Select Categories", 'otvcp-i10n'),
         "param_name"=> "idcate_testimonials",
         "value"     => "",
         "description" => __("Enter your testimonials category.", 'otvcp-i10n'),
      ),     
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number show testimonial per page.",
         "param_name" => "number",
         "value" => "",
         "description" => __("Add Number -1 for show all post.", 'otvcp-i10n')
      ),    
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select Columns.", 'otvcp-i10n'),
         "param_name" => "testi_columns",
         "value" => array(   
                     __('4 Columns', 'otvcp-i10n') => 4,
                     __('3 Columns', 'otvcp-i10n') => 3,
                     __('2 Columns', 'otvcp-i10n') => 2,
                    ),
         "description" => __("Select number columns for show.", 'otvcp-i10n')
      ),    
    )
    ));
}

if ( ! function_exists( 'is_plugin_active' ) ) {
  require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {     
  if ( function_exists( 'vc_add_shortcode_param' ) ) {
     vc_add_shortcode_param( 'select_category_testimonials', 'select_param_testimonials', OTVCP_DIR . 'assets/javascripts/select-field-testimonials.js' );
  } elseif ( function_exists( 'add_shortcode_param' ) ) {
     add_shortcode_param( 'select_category_testimonials', 'select_param_testimonials', OTVCP_DIR . 'assets/javascripts/select-field-testimonials.js' );
  }
}   

function select_param_testimonials( $settings, $value ) {  
  $category_testimonials = get_terms( 'category_testimonial' );
  $cat_testimonials = array();
  foreach( $category_testimonials as $category ) {
     if( $category ) {
        $cat_testimonials[] = sprintf('<option value="%s">%s</option>',
           esc_attr( $category->slug ),
           $category->name
        );
     }

  }

  return sprintf(
     '<input type="hidden" name="%s" value="%s" class="wpb-input-category_testimonials wpb_vc_param_value wpb-textinput %s %s_field">
     <select class="select-category_testimonials-post">
     %s
     </select>',
     esc_attr( $settings['param_name'] ),
     esc_attr( $value ),
     esc_attr( $settings['param_name'] ),
     esc_attr( $settings['type'] ),
     implode( '', $cat_testimonials )
  );
}

// Gallery Image
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Gallery", 'otvcp-i10n'),
   "base"      => "gocargo_gallery",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(      
      array(
         "type" => "attach_images",
         "holder" => "div",
         "class" => "",
         "heading" => "Add Gallery",
         "param_name" => "gallery",
         "value" => "",
         "description" => __("Add Gallery Image.", 'otvcp-i10n')
      ),   
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select Columns.", 'otvcp-i10n'),
         "param_name" => "gallery_columns",
         "value" => array(   
                     __('4 Columns', 'otvcp-i10n') => 4,
                     __('3 Columns', 'otvcp-i10n') => 3,
                     __('2 Columns', 'otvcp-i10n') => 2,
                    ),
         "description" => __("Select number columns for show.", 'otvcp-i10n')
      ),
    )));
}

// Gallery Image 2
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Gallery 2", 'otvcp-i10n'),
   "base"      => "gocargo_gallery2",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(      
      array(
         "type" => "attach_images",
         "holder" => "div",
         "class" => "",
         "heading" => "Add Gallery",
         "param_name" => "gallery",
         "value" => "",
         "description" => __("Add Gallery Image.", 'otvcp-i10n')
      ),   
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select Columns.", 'otvcp-i10n'),
         "param_name" => "gallery_columns",
         "value" => array(   
                     __('4 Columns', 'otvcp-i10n') => 4,
                     __('3 Columns', 'otvcp-i10n') => 3,
                     __('2 Columns', 'otvcp-i10n') => 2,
                    ),
         "description" => __("Select number columns for show.", 'otvcp-i10n')
      ),
    )));
}

// Gallery Image
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Gallery Slider", 'otvcp-i10n'),
   "base"      => "gocargo_gallery_slider",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(      
      array(
         "type" => "attach_images",
         "holder" => "div",
         "class" => "",
         "heading" => "Add Gallery",
         "param_name" => "gallery",
         "value" => "",
         "description" => __("Add Gallery Image.", 'otvcp-i10n')
      ),   
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select Columns.", 'otvcp-i10n'),
         "param_name" => "gallery_columns",
         "value" => array(   
                     __('4 Columns', 'otvcp-i10n') => 4,
                     __('3 Columns', 'otvcp-i10n') => 3,
                     __('2 Columns', 'otvcp-i10n') => 2,
                    ),
         "description" => __("Select number columns for show.", 'otvcp-i10n')
      ),
    )));
}

// About Us
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT About Us", 'otvcp-i10n'),
   "base"      => "about_box",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Add icon class", 'otvcp-i10n'),
         "param_name" => "icon",
         "value" => "",
         "description" => __("Ex: icon-<code>wallet</code>, <a href='http://vegatheme.com/html/archi-icons-etlinefont/' target='_blank'>view more icon class</a>", 'otvcp-i10n')
      ),    
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Description", 'otvcp-i10n'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Content right.", 'otvcp-i10n')
      ),
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ),  
      array(
         "type" => "vc_link",
         "holder" => "div",
         "class" => "",
         "heading" => __("link Title", 'otvcp-i10n'),
         "param_name" => "linkbox",
         "value" => "",
         "description" => __("Add Link to Title", 'otvcp-i10n')
      ),     
    )));
}

// About US 2
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT About US 2", 'otvcp-i10n'),
   "base"      => "about_us2",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(
      array(
         "type" => "attach_image",
         "holder" => "div",
         "class" => "",
         "heading" => "Photo",
         "param_name" => "photo",
         "value" => "",
         "description" => __("Photo", 'otvcp-i10n')
      ),        
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Description", 'otvcp-i10n'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Content right.", 'otvcp-i10n')
      ),
      array(
        'type' => 'vc_link',
         "heading" => __("Link Button", 'otvcp-i10n'),
         "param_name" => "linkbox",         
         "description" => __("Add link to button.", 'otvcp-i10n')
      ), 
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ),       
    )));
}

// About US 3
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT About US 3", 'otvcp-i10n'),
   "base"      => "about_us3",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(
      array(
         "type" => "attach_image",
         "holder" => "div",
         "class" => "",
         "heading" => "Photo",
         "param_name" => "photo",
         "value" => "",
         "description" => __("Photo", 'otvcp-i10n')
      ),        
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Description", 'otvcp-i10n'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Content right.", 'otvcp-i10n')
      ),
      array(
        'type' => 'vc_link',
         "heading" => __("Link Button", 'otvcp-i10n'),
         "param_name" => "linkbox",         
         "description" => __("Add link to button.", 'otvcp-i10n')
      ), 
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ),       
    )));
}

// About US 4 use on preview 3
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT About US 4", 'otvcp-i10n'),
   "base"      => "about_us4",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon_fontawesome',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),         
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Description", 'otvcp-i10n'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Content right.", 'otvcp-i10n')
      ),
      array(
        'type' => 'vc_link',
         "heading" => __("Link Button", 'otvcp-i10n'),
         "param_name" => "linkbox",         
         "description" => __("Add link to button.", 'otvcp-i10n')
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Animate delay time", 'otvcp-i10n'),
         "param_name" => "wowdelay",
         "value" => "",
         "description" => __("Ex: .4, 1, 1.5, etc", 'otvcp-i10n')
      ),
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ),       
    )));
}

// About us 5 use on GoCargo Express
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT About US 5", 'otvcp-i10n'),
   "base"      => "about_us5",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon_fontawesome',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),         
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Description", 'otvcp-i10n'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Content right.", 'otvcp-i10n')
      ),
      array(
        'type' => 'vc_link',
         "heading" => __("Link Button", 'otvcp-i10n'),
         "param_name" => "linkbox",         
         "description" => __("Add link to button.", 'otvcp-i10n')
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Icon animate delay time", 'otvcp-i10n'),
         "param_name" => "icondelay",
         "value" => "",
         "description" => __("Ex: .4, 1, 1.5, etc", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Text animate delay time", 'otvcp-i10n'),
         "param_name" => "textdelay",
         "value" => "",
         "description" => __("Ex: .4, 1, 1.5, etc", 'otvcp-i10n')
      ),
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select Border Box", 'otvcp-i10n'),
         "param_name" => "borderbox",
         "value" => array(   
                     __('Yes', 'otvcp-i10n') => 'yes',
                     __('No', 'otvcp-i10n') => 'no',
                    ),
         "description" => __("Select border box.", 'otvcp-i10n')
      ),       
    )));
}


// Service Box
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Service Grid", 'otvcp-i10n'),
   "base" => "service_grid",
   'admin_enqueue_js'  => OTVCP_DIR . 'assets/javascripts/select2.min.js',
   'admin_enqueue_css' => OTVCP_DIR . 'assets/stylesheets/select2.css',
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number show services per page.",
         "param_name" => "number",
         "value" => "",
         "description" => __("Add Number -1 for show all post.", 'otvcp-i10n')
      ),    
	  array(
         "type"      => "select_categories",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Select Category", 'otvcp-i10n'),
         "param_name"=> "idcate",
         "value"     => "",
         "description" => __("Show services post by category, leave a blank do not show service by category, it's show all services.", 'otvcp-i10n')
      ),	
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select Columns.", 'otvcp-i10n'),
         "param_name" => "service_columns",
         "value" => array(   
                     __('6 Columns', 'otvcp-i10n') => 6,
                     __('5 Columns', 'otvcp-i10n') => 5,
                     __('4 Columns', 'otvcp-i10n') => 4,
                     __('3 Columns', 'otvcp-i10n') => 3,
                     __('2 Columns', 'otvcp-i10n') => 2,
                    ),
         "description" => __("Select number columns for show.", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Button Text", 'otvcp-i10n'),
         "param_name" => "btntext",
         "value" => "",
         "description" => __("Add your button text, default: Read More", 'otvcp-i10n')
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select show or hide service button.", 'otvcp-i10n'),
         "param_name" => "show_hide_btn",
         "value" => array(                                          
                     __('Show', 'otvcp-i10n') => 'show',
                     __('Hide', 'otvcp-i10n') => 'hide',
                    ),
         "description" => __("Select show or hide service button, default: show service button.", 'otvcp-i10n')
      ),
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ), 
    )));
}

// Service Box 2
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Service Grid 2", 'otvcp-i10n'),
   "base" => "service_grid2",
   'admin_enqueue_js'  => OTVCP_DIR . 'assets/javascripts/select2.min.js',
   'admin_enqueue_css' => OTVCP_DIR . 'assets/stylesheets/select2.css',
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number show services per page.",
         "param_name" => "number",
         "value" => "",
         "description" => __("Add Number -1 for show all post.", 'otvcp-i10n')
      ),
	  array(
         "type"      => "select_categories",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Select Category", 'otvcp-i10n'),
         "param_name"=> "idcate",
         "value"     => "",
         "description" => __("Show services post by category, leave a blank do not show service by category, it's show all services.", 'otvcp-i10n')
      ), 	
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select Columns.", 'otvcp-i10n'),
         "param_name" => "service_columns",
         "value" => array(   
                     __('2 Columns', 'otvcp-i10n') => 2,                     
                     __('3 Columns', 'otvcp-i10n') => 3,
                     __('4 Columns', 'otvcp-i10n') => 4,
                    ),
         "description" => __("Select number columns for show.", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Button Text", 'otvcp-i10n'),
         "param_name" => "btntext",
         "value" => "",
         "description" => __("Add your button text, default: View Details", 'otvcp-i10n')
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select show or hide service button.", 'otvcp-i10n'),
         "param_name" => "show_hide_btn",
         "value" => array(                                          
                     __('Show', 'otvcp-i10n') => 'show',
                     __('Hide', 'otvcp-i10n') => 'hide',
                    ),
         "description" => __("Select show or hide service button, default: show service button.", 'otvcp-i10n')
      ),
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ), 
    )));
}


// Service Box 3
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Service Grid 3", 'otvcp-i10n'),
   "base" => "service_grid3",
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(      
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Description", 'otvcp-i10n'),
         "param_name" => "desc",
         "value" => "",
         "description" => __("Description", 'otvcp-i10n')
      ),        
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number show services per page.",
         "param_name" => "number",
         "value" => "",
         "description" => __("Add Number -1 for show all post.", 'otvcp-i10n')
      ),
	  array(
         "type"      => "select_categories",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Select Category", 'otvcp-i10n'),
         "param_name"=> "idcate",
         "value"     => "",
         "description" => __("Show services post by category, leave a blank do not show service by category, it's show all services.", 'otvcp-i10n')
      ), 	
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select Columns.", 'otvcp-i10n'),
         "param_name" => "service_columns",
         "value" => array(   
                     __('2 Columns', 'otvcp-i10n') => 2,                     
                     __('3 Columns', 'otvcp-i10n') => 3,
                     __('4 Columns', 'otvcp-i10n') => 4,
                    ),
         "description" => __("Select number columns for show.", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Button Text", 'otvcp-i10n'),
         "param_name" => "btntext",
         "value" => "",
         "description" => __("Add your button text, default: View Details", 'otvcp-i10n')
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select show or hide service button.", 'otvcp-i10n'),
         "param_name" => "show_hide_btn",
         "value" => array(                                          
                     __('Show', 'otvcp-i10n') => 'show',
                     __('Hide', 'otvcp-i10n') => 'hide',
                    ),
         "description" => __("Select show or hide service button, default: show service button.", 'otvcp-i10n')
      ),
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ), 
    )));
}

// Service Box 4 use in preview 3
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Service Grid 4", 'otvcp-i10n'),
   "base" => "service_grid4",
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(      
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ),       
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number show services per page.",
         "param_name" => "number",
         "value" => "",
         "description" => __("Add Number -1 for show all post.", 'otvcp-i10n')
      ),
     array(
         "type"      => "select_categories",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Select Category", 'otvcp-i10n'),
         "param_name"=> "idcate",
         "value"     => "",
         "description" => __("Show services post by category, leave a blank do not show service by category, it's show all services.", 'otvcp-i10n')
      ),    
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select Columns.", 'otvcp-i10n'),
         "param_name" => "service_columns",
         "value" => array(                                          
                     __('3 Columns', 'otvcp-i10n') => 3,
                     __('4 Columns', 'otvcp-i10n') => 4,
                    ),
         "description" => __("Select number columns for show.", 'otvcp-i10n')
      ),
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select layout style.", 'otvcp-i10n'),
         "param_name" => "service_style",
         "value" => array(                                          
                     __('Style Dark', 'otvcp-i10n') => 'dark',
                     __('Style Light', 'otvcp-i10n') => 'light',
                    ),
         "description" => __("Select layout style for display.", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Button Text", 'otvcp-i10n'),
         "param_name" => "btntext",
         "value" => "",
         "description" => __("Add your button text, default: View Details", 'otvcp-i10n')
      ), 
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select show or hide service button.", 'otvcp-i10n'),
         "param_name" => "show_hide_btn",
         "value" => array(                                          
                     __('Show', 'otvcp-i10n') => 'show',
                     __('Hide', 'otvcp-i10n') => 'hide',
                    ),
         "description" => __("Select show or hide service button, default: show service button.", 'otvcp-i10n')
      ),
    )));
}

// Service Slider in Onepage express
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Service Slider", 'otvcp-i10n'),
   "base" => "ot_service_slider",
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(      
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ),       
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number show services per page.",
         "param_name" => "number",
         "value" => "",
         "description" => __("Add Number -1 for show all post.", 'otvcp-i10n')
      ),
     array(
         "type"      => "select_categories",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Select Category", 'otvcp-i10n'),
         "param_name"=> "idcate",
         "value"     => "",
         "description" => __("Show services post by category, leave a blank do not show service by category, it's show all services.", 'otvcp-i10n')
      ),   
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Button Text", 'otvcp-i10n'),
         "param_name" => "btntext",
         "value" => "",
         "description" => __("Add your button text, default: View Details", 'otvcp-i10n')
      ), 
      array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select show or hide service button.", 'otvcp-i10n'),
         "param_name" => "show_hide_btn",
         "value" => array(                                          
                     __('Show', 'otvcp-i10n') => 'show',
                     __('Hide', 'otvcp-i10n') => 'hide',
                    ),
         "description" => __("Select show or hide service button, default: show service button.", 'otvcp-i10n')
      ),
    )));
}

//Use this code for all : Service Box, Service Box 2, Service Box 3
if ( ! function_exists( 'is_plugin_active' ) ) {
   require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {     
   if ( function_exists( 'vc_add_shortcode_param' ) ) {
      vc_add_shortcode_param( 'select_categories', 'select_param', OTVCP_DIR . 'assets/javascripts/select-field.js' );
   } elseif ( function_exists( 'add_shortcode_param' ) ) {
      add_shortcode_param( 'select_categories', 'select_param', OTVCP_DIR . 'assets/javascripts/select-field.js' );
   }
}   

function select_param( $settings, $value ) {
   $categories = get_terms( 'category_service' );
   $cat = array();
   foreach( $categories as $category ) {
      if( $category ) {
         $cat[] = sprintf('<option value="%s">%s</option>',
            esc_attr( $category->slug ),
            $category->name
         );
      }

   }

   return sprintf(
      '<input type="hidden" name="%s" value="%s" class="wpb-input-categories wpb_vc_param_value wpb-textinput %s %s_field">
      <select class="select-categories-post">
      %s
      </select>',
      esc_attr( $settings['param_name'] ),
      esc_attr( $value ),
      esc_attr( $settings['param_name'] ),
      esc_attr( $settings['type'] ),
      implode( '', $cat )
   );
}

// Other Services (use)
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Other Service", 'otvcp-i10n'),
   "base" => "other_service",
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(    
      array(
         "type" => "attach_image",
         "holder" => "div",
         "class" => "",
         "heading" => "Photo",
         "param_name" => "photo",
         "value" => "",
         "description" => __("Photo Other Service", 'otvcp-i10n')
      ),   
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title display in Other Service box.", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Content", 'otvcp-i10n'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Content display in Other Service box.", 'otvcp-i10n')
      ),      
     array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Delay animation number", 'otvcp-i10n'),
         "param_name" => "delay",
         "value" => "",
         "description" => __("Add Delay animation number.", 'otvcp-i10n')
      ),
     array(
         "type" => "dropdown",
         "holder" => "div",
         "class" => "",
         "heading" => __("Select Columns.", 'otvcp-i10n'),
         "param_name" => "service_columns",
         "value" => array(   
                     __('2 Columns', 'otvcp-i10n') => 2,                     
                     __('3 Columns', 'otvcp-i10n') => 3,
                     __('4 Columns', 'otvcp-i10n') => 4,
                     __('5 Columns', 'otvcp-i10n') => 5,
                    ),
         "description" => __("Select number columns for show.", 'otvcp-i10n')
      ),
     array(
        "type" => "dropdown",
        "holder" => "div",
        "class" => "",
        "heading" => __('Animate Column', 'otvcp-i10n'),
        "param_name" => "animate",
        "value" => array(   
                     __('None', 'otvcp-i10n') => 'none', 
                     __('Fade In Up', 'otvcp-i10n') => 'fadeinup', 
                     __('Fade In Down', 'otvcp-i10n') => 'fadeindown', 
                     __('Fade In', 'otvcp-i10n') => 'fadein', 
                     __('Fade In Left', 'otvcp-i10n') => 'fadeinleft',  
                     __('Fade In Right', 'otvcp-i10n') => 'fadinright',
                    ),
        "description" => __("Select Animate , Default: None", "gocargo"),      
      ) 
    )));
}

// Our Facts (use)
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Our Facts", 'otvcp-i10n'),
   "base" => "ourfacts",
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(      
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title Fact", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title display in Our Facts box.", 'otvcp-i10n')
      ),
     array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Number Fact", 'otvcp-i10n'),
         "param_name" => "number",
         "value" => "",
         "description" => __("Number display in Our Facts box.", 'otvcp-i10n')
      ),      
    )));
}

//Social Group
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Social Group", 'otvcp-i10n'),
   "base" => "socialgroup",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'GoCargo Element',
   "params" => array(      
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Add your title.", 'otvcp-i10n')
      ),
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon 1', 'otvcp-i10n' ),
         'param_name' => 'icon1',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),
     array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 1",
         "param_name"=> "url1",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
     array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon 2', 'otvcp-i10n' ),
         'param_name' => 'icon2',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),
     array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 2",
         "param_name"=> "url2",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
     array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon 3', 'otvcp-i10n' ),
         'param_name' => 'icon3',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),
     array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 3",
         "param_name"=> "url3",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
     array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon 4', 'otvcp-i10n' ),
         'param_name' => 'icon4',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),
     array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 4",
         "param_name"=> "url4",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
     array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon 5', 'otvcp-i10n' ),
         'param_name' => 'icon5',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),
     array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 5",
         "param_name"=> "url5",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
     array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon 6', 'otvcp-i10n' ),
         'param_name' => 'icon6',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),
     array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 6",
         "param_name"=> "url6",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
    )));
}

//Our Team
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Our Team", 'otvcp-i10n'),
   "base" => "team",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'GoCargo Element',
   "params" => array(
      array(
         "type" => "attach_image",
         "holder" => "div",
         "class" => "",
         "heading" => "Photo Member",
         "param_name" => "photo",
         "value" => "",
         "description" => __("Avarta of member, Recomended Size: 420 x 420", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Member Name", 'otvcp-i10n'),
         "param_name" => "name",
         "value" => "",
         "description" => __("Member's Name", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Member Job", 'otvcp-i10n'),
         "param_name" => "job",
         "value" => "",
         "description" => __("Member's job.", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => "Member Description",
         "param_name" => "content",
         "value" => "",
         "description" => __("Description", 'otvcp-i10n')
      ), 
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon 1', 'otvcp-i10n' ),
         'param_name' => 'icon1',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),
     array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 1",
         "param_name"=> "url1",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
     array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon 2', 'otvcp-i10n' ),
         'param_name' => 'icon2',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),
     array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 2",
         "param_name"=> "url2",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
     array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon 3', 'otvcp-i10n' ),
         'param_name' => 'icon3',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),
     array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 3",
         "param_name"=> "url3",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
     array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon 4', 'otvcp-i10n' ),
         'param_name' => 'icon4',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),
     array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 4",
         "param_name"=> "url4",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
     array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon 5', 'otvcp-i10n' ),
         'param_name' => 'icon5',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),
     array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 5",
         "param_name"=> "url5",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
     array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon 6', 'otvcp-i10n' ),
         'param_name' => 'icon6',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),
     array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 6",
         "param_name"=> "url6",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
    )));
}

//Our Team 2
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Our Team 2", 'otvcp-i10n'),
   "base" => "team2",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'GoCargo Element',
   "params" => array(
      array(
         "type" => "attach_image",
         "holder" => "div",
         "class" => "",
         "heading" => "Photo Member",
         "param_name" => "photo",
         "value" => "",
         "description" => __("Avarta of member, Recomended Size: 420 x 420", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Member Name", 'otvcp-i10n'),
         "param_name" => "name",
         "value" => "",
         "description" => __("Member's Name", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Member Job", 'otvcp-i10n'),
         "param_name" => "job",
         "value" => "",
         "description" => __("Member's job.", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => "Member Description",
         "param_name" => "content",
         "value" => "",
         "description" => __("Description", 'otvcp-i10n')
      ), 
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon1',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ), 
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 1",
         "param_name"=> "url1",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon2',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ), 
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 2",
         "param_name"=> "url2",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon3',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ), 
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 3",
         "param_name"=> "url3",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon4',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ), 
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 4",
         "param_name"=> "url4",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon5',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ), 
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 5",
         "param_name"=> "url5",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon6',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ), 
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 6",
         "param_name"=> "url6",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
    )));
}

//Our Team 3 use in preview 3
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Our Team 3", 'otvcp-i10n'),
   "base" => "team3",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'GoCargo Element',
   "params" => array(
      array(
         "type" => "attach_image",
         "holder" => "div",
         "class" => "",
         "heading" => "Photo Member",
         "param_name" => "photo",
         "value" => "",
         "description" => __("Avarta of member, Recomended Size: 420 x 420", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Member Name", 'otvcp-i10n'),
         "param_name" => "name",
         "value" => "",
         "description" => __("Member's Name", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Member Job", 'otvcp-i10n'),
         "param_name" => "job",
         "value" => "",
         "description" => __("Member's job.", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => "Member Description",
         "param_name" => "content",
         "value" => "",
         "description" => __("Description", 'otvcp-i10n')
      ), 
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon1',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ), 
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 1",
         "param_name"=> "url1",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon2',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ), 
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 2",
         "param_name"=> "url2",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon3',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ), 
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 3",
         "param_name"=> "url3",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon4',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ), 
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 4",
         "param_name"=> "url4",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon5',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ), 
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 5",
         "param_name"=> "url5",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon6',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ), 
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => "Url 6",
         "param_name"=> "url6",
         "value"     => "",
         "description" => __("Url.", 'otvcp-i10n')
      ),
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ), 
    )));
}

// Latest Blog
if(function_exists('vc_map')){   
   vc_map( array(
   "name" => __("OT Latest Blog", 'otvcp-i10n'),
   "base" => "latestblog",
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(      
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Show",
         "param_name" => "number",
         "value" => "",
         "description" => __("Number", 'otvcp-i10n')
      ),    
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Excerpt",
         "param_name" => "excerpt",
         "value" => "",
         "description" => __("Number", 'otvcp-i10n')
      ),
      array(
        "type" => "dropdown",
        "holder" => "div",
        "class" => "",
        "heading" => __('Select columns', 'otvcp-i10n'),
        "param_name" => "columns",
        "value" => array(   
                     __('2 Columns', 'otvcp-i10n') => '2col',
                     __('3 Columns', 'otvcp-i10n') => '3col',  
                     __('4 Columns', 'otvcp-i10n') => '4col',                 
                    ),
        "description" => __("Select number columns per row.", 'otvcp-i10n'),      
      ),  
      array(
        'type' => 'vc_link',
         "heading" => __("Link Button", 'otvcp-i10n'),
         "param_name" => "linkbox",         
         "description" => __("Add link to button.", 'otvcp-i10n')
      ),      
    )
    ));
}

// Latest Blog 2
if(function_exists('vc_map')){   
   vc_map( array(
   "name" => __("OT Latest Blog 2", 'otvcp-i10n'),
   "base" => "latestblog2",
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(      
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Show post",
         "param_name" => "number",
         "value" => "",
         "description" => __("Number", 'otvcp-i10n')
      ),    
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Excerpt",
         "param_name" => "excerpt",
         "value" => "",
         "description" => __("Number", 'otvcp-i10n')
      ), 
      array(
        "type" => "dropdown",
        "holder" => "div",
        "class" => "",
        "heading" => __('Select columns', 'otvcp-i10n'),
        "param_name" => "columns",
        "value" => array(   
                     __('2 Columns', 'otvcp-i10n') => '2col',
                     __('3 Columns', 'otvcp-i10n') => '3col',  
                     __('4 Columns', 'otvcp-i10n') => '4col',                 
                    ),
        "description" => __("Select number columns per row.", 'otvcp-i10n'),      
      ),     
    )
    ));
}

// Latest Blog 3
if(function_exists('vc_map')){   
   vc_map( array(
   "name" => __("OT Latest Blog 3", 'otvcp-i10n'),
   "base" => "latestblog3",
   "class" => "",
   "category" => 'GoCargo Element',
   "icon" => "icon-st",
   "params" => array(      
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Show",
         "param_name" => "number",
         "value" => "",
         "description" => __("Number", 'otvcp-i10n')
      ),    
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => "Number Excerpt",
         "param_name" => "excerpt",
         "value" => "",
         "description" => __("Number", 'otvcp-i10n')
      ),
      array(
        "type" => "dropdown",
        "holder" => "div",
        "class" => "",
        "heading" => __('Select columns', 'otvcp-i10n'),
        "param_name" => "columns",
        "value" => array(   
                     __('2 Columns', 'otvcp-i10n') => '2col',
                     __('3 Columns', 'otvcp-i10n') => '3col',  
                     __('4 Columns', 'otvcp-i10n') => '4col',                 
                    ),
        "description" => __("Select number columns per row.", 'otvcp-i10n'),      
      ),       
   )
   ));
}

// Contact Info
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Contact Info", 'otvcp-i10n'),
   "base"      => "info_contact",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(       
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Description", 'otvcp-i10n'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Content right.", 'otvcp-i10n')
      ),
      array(
        'type' => 'vc_link',
         "heading" => __("Link Button", 'otvcp-i10n'),
         "param_name" => "linkbox",         
         "description" => __("Add link to button.", 'otvcp-i10n')
      ), 
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ),       
    )));
}

// Contact Info 2
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Contact Info 2", 'otvcp-i10n'),
   "base"      => "info_contact2",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(   
      array(
         'type' => 'iconpicker',
         'heading' => __( 'Icon', 'otvcp-i10n' ),
         'param_name' => 'icon_fontawesome',
         'value' => '',
         'settings' => array(
            'emptyIcon' => false, // default true, display an "EMPTY" icon?
            'iconsPerPage' => 4000, // default 100, how many icons per/page to display
         ),         
         'description' => __( 'Select icon from library.', 'otvcp-i10n' ),
      ),     
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Description", 'otvcp-i10n'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Content right.", 'otvcp-i10n')
      ),
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ),       
    )));
}

// OT FAQs
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT FAQs", 'otvcp-i10n'),
   "base"      => "ot_faqs",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(       
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Description", 'otvcp-i10n'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Content right.", 'otvcp-i10n')
      ),        
    )));
}

//Close Map
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Close Map", 'otvcp-i10n'),
   "base"      => "closemap",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(
      array(
         "type"      => "textfield",
         "holder"    => "div",
         "class"     => "",
         "heading"   => __("Title", 'otvcp-i10n'),
         "param_name"=> "title",
         "value"     => "",
         "description" => __("Add title", 'otvcp-i10n'),
      ),                 
    )));
}


//Google Map
if(function_exists('vc_map')){
   vc_map( array(
   "name" => __("OT Google Map", 'otvcp-i10n'),
   "base" => "ggmap",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'GoCargo Element',
   "params" => array(        
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Height Map", 'otvcp-i10n'),
         "param_name" => "height",
         "value" => 480,
         "description" => __("Please enter number height Map, 300, 350, 380, ..etc. Default: 420.", 'otvcp-i10n')
      ),    
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Latitude", 'otvcp-i10n'),
         "param_name" => "lat",
         "value" => 40.6700,
         "description" => __("Please enter <a href='http://www.latlong.net/'>Latitude</a> google map", 'otvcp-i10n')
      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Longitude", 'otvcp-i10n'),
         "param_name" => "long",
         "value" => -73.9400,
         "description" => __("Please enter <a href='http://www.latlong.net/'>Longitude</a> google map", 'otvcp-i10n')

      ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Zoom Map", 'otvcp-i10n'),
         "param_name" => "zoom",
         "value" => 12,
         "description" => __("Please enter Zoom Map, Default: 15", 'otvcp-i10n')
      ),           
      array(
         "type" => "attach_image",
         "holder" => "div",
         "class" => "",
         "heading" => "Icon Map marker",
         "param_name" => "icon",
         "value" => "",
         "description" => __("Icon Map marker, 85 x 85", 'otvcp-i10n')
      ), 
      array(
        "type" => "dropdown",
        "heading" => __('Select map style', 'otvcp-i10n'),
        "param_name" => "style",
        "value" => array(   
                     __('Map Dark', 'otvcp-i10n') => 'dark',
                     __('Map Light', 'otvcp-i10n') => 'light',
                     __('Customize Gmap Style', 'otvcp-i10n') => 'customize_gmap',                 
                    ),
        "description" => __("Select amp style dark or light or custom map.", 'otvcp-i10n'),      
      ),    
		array(
			"type" => "textarea_raw_html",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__('JavaScript Code', 'otvcp-i10n'),
			"param_name" => "gmap_custom_style",
			"value" => "",
			"description" => __('Enter your JavaScript code, find your custom style gmap here:<a href="https://snazzymaps.com/explore" target="_blank">view more</a>', 'archi'),   
			"dependency"  => array( 'element' => 'style', 'value' => 'customize_gmap' ),   
		),       
    )));
}

// OT BOARD OF DIRECTOR
if(function_exists('vc_map')){
   vc_map(array(
      "name"      => __("OT BOARD OF DIRECTOR", 'otvcp-i10n'),
      "base"      => "ot_board_of_director",
      "class"     => "",
      "icon" => "icon-st",
      "category"  => 'GoCargo Element',
      "params"    => array(
         array(
            'type' => 'textfield',
            "holder" => "div",
            "class" => "",
            'value' => '',
            'heading' => 'Title',
            'param_name' => 'title',
         ),  
         // params group
         array(
            'type' => 'param_group',
            'value' => '',
            'param_name' => 'titles',
            // Note params is mapped inside param-group:
            'params' => array(
               array(
                  "type" => "attach_image",
                  "holder" => "div",
                  "class" => "",
                  "heading" => __("Avatar", 'otvcp-i10n'),
                  "param_name" => "avatar",
                  "value" => "",
                  "description" => __("Upload avatar", 'otvcp-i10n')
               ),
               array(
                  'type' => 'textfield',
                  "holder" => "div",
                  "class" => "",
                  'heading' => 'Name',
                  'param_name' => 'title',
                  "value" => "",
                  "description" => __("Add Name", 'otvcp-i10n')
               ),
               array(
                  'type' => 'textarea',
                  "holder" => "div",
                  "class" => "",
                  'heading' => 'Info',
                  'param_name' => 'desc',
                  "value" => "",
                  "description" => __("Add Info", 'otvcp-i10n')
               )
            )                
         ),
         array(
             "type"      => "textfield",
             "holder"    => "div",
             "class"     => "",
             "heading"   => __("Extra class name", 'otvcp-i10n'),
             "param_name"=> "extraclass",
             "value"     => "",
             "description" => __("Style particular content element differently - add a class name and refer to it in custom CSS.", 'otvcp-i10n')
         ), 
      )
   )
);
}

// OT Contact Info 3 use in GoCargo Express version
if(function_exists('vc_map')){
   vc_map(array(
      "name"      => __("OT CONTACT INFO 3", 'otvcp-i10n'),
      "base"      => "contact_info3",
      "class"     => "",
      "icon" => "icon-st",
      "category"  => 'GoCargo Element',
      "params"    => array(
         array(
            'type' => 'textfield',
            "holder" => "div",
            "class" => "",
            'value' => '',
            'heading' => 'Title',
            'param_name' => 'title',
         ),  
         array(
            'type' => 'textarea',
            "holder" => "div",
            "class" => "",
            'heading' => 'Office Address',
            'param_name' => 'address',
            "value" => "",
            "description" => __("Add Your Address", 'otvcp-i10n')
         ),
         array(
            'type' => 'textarea',
            "holder" => "div",
            "class" => "",
            'heading' => 'Phone Number',
            'param_name' => 'phone',
            "value" => "",
            "description" => __("Add Your Phone Number", 'otvcp-i10n')
         ),
         array(
            'type' => 'textarea',
            "holder" => "div",
            "class" => "",
            'heading' => 'Email Address',
            'param_name' => 'email',
            "value" => "",
            "description" => __("Add Your Email Address", 'otvcp-i10n')
         ),
         // params group
         array(
            'type' => 'param_group',
            'value' => '',
            'param_name' => 'socials',
            // Note params is mapped inside param-group:
            'params' => array(
               array(
                  'type' => 'textfield',
                  "holder" => "div",
                  "class" => "",
                  'heading' => 'Social Icon',
                  'param_name' => 'link_icon',
                  "value" => "",
                  "description" => __("Add Icon Class Name, find more icon here: http://fontawesome.io/icons/", 'otvcp-i10n')
               ),
               array(
                  'type' => 'textfield',
                  "holder" => "div",
                  "class" => "",
                  'heading' => 'Social Link Url',
                  'param_name' => 'link_url',
                  "value" => "",
                  "description" => __("Add Link Url", 'otvcp-i10n')
               )
            )                
         ),
         array(
            "type"      => "textfield",
            "holder"    => "div",
            "class"     => "",
            "heading"   => __("Extra class name", 'otvcp-i10n'),
            "param_name"=> "extraclass",
            "value"     => "",
            "description" => __("Style particular content element differently - add a class name and refer to it in custom CSS.", 'otvcp-i10n')
         ), 
      )
   )
);
}

// OT Footer Box - Use in GoCargo Express
if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Footer Box", 'otvcp-i10n'),
   "base"      => "ot_footer_box",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(   
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Add icon class", 'otvcp-i10n'),
         "param_name" => "icon",
         "value" => "",
         "description" => __("Ex: fa-<code>facebook</code>, <a href='http://fontawesome.io/icons/' target='_blank'>view more icon class</a>", 'otvcp-i10n')
      ),     
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'otvcp-i10n'),
         "param_name" => "title",
         "value" => "",
         "description" => __("Title", 'otvcp-i10n')
      ),
      array(
         "type" => "textarea_html",
         "holder" => "div",
         "class" => "",
         "heading" => __("Content", 'otvcp-i10n'),
         "param_name" => "content",
         "value" => "",
         "description" => __("Content right.", 'otvcp-i10n')
      ),     
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Extra class name", 'otvcp-i10n'),
         "param_name" => "extra_class",
         "value" => "",
         "description" => __("Add extra class name for custom style.", 'otvcp-i10n')
      ), 
      array(
         'type' => 'css_editor',
         'heading' => __( 'CSS box', 'otvcp-i10n' ),
         'param_name' => 'css',
         // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'otvcp-i10n' ),
         'group' => __( 'Design Options', 'otvcp-i10n' )
      ),      
    )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name"      => __("OT Branch info Tabs", 'otvcp-i10n'),
   "base"      => "branch_info_tab",
   "class"     => "",
   "icon" => "icon-st",
   "category"  => 'GoCargo Element',
   "params"    => array(              
      array(
         'type' => 'textfield',
         "holder" => "div",
         "class" => "",
         'value' => '',
         'heading' => 'Title',
         'param_name' => 'title',
      ),      
      // params group
      array(
         'type' => 'param_group',
         'value' => '',
         'param_name' => 'branchs',
         // Note params is mapped inside param-group:
         'params' => array(
            array(
               "type" => "textfield",
               "holder" => "div",
               "class" => "",
               "heading" => __("Title Tab", 'otvcp-i10n'),
               "param_name" => "title",
               "value" => "",
               "description" => __("Title", 'otvcp-i10n')
            ),
            array(
               "type" => "textfield",
               "holder" => "div",
               "class" => "",
               "heading" => __("SubTitle Tab", 'otvcp-i10n'),
               "param_name" => "subtitle",
               "value" => "",
               "description" => __("Title", 'otvcp-i10n')
            ),
            array(
               'type' => 'textarea',
               "holder" => "div",
               "class" => "",
               'heading' => 'Office Address',
               'param_name' => 'address',
               "value" => "",
               "description" => __("Add Your Address", 'otvcp-i10n')
            ),
            array(
               'type' => 'textarea',
               "holder" => "div",
               "class" => "",
               'heading' => 'Phone Number',
               'param_name' => 'phone',
               "value" => "",
               "description" => __("Add Your Phone Number", 'otvcp-i10n')
            ),
            array(
               'type' => 'textarea',
               "holder" => "div",
               "class" => "",
               'heading' => 'Email Address',
               'param_name' => 'email',
               "value" => "",
               "description" => __("Add Your Email Address", 'otvcp-i10n')
            ),
            array(
               "type" => "textfield",
               "holder" => "div",
               "class" => "",
               "heading" => __("Latitude", 'otvcp-i10n'),
               "param_name" => "lat",
               "value" => 40.6700,
               "description" => __("Please enter <a href='http://www.latlong.net/'>Latitude</a> google map", 'otvcp-i10n')
            ),
            array(
               "type" => "textfield",
               "holder" => "div",
               "class" => "",
               "heading" => __("Longitude", 'otvcp-i10n'),
               "param_name" => "long",
               "value" => -73.9400,
               "description" => __("Please enter <a href='http://www.latlong.net/'>Longitude</a> google map", 'otvcp-i10n')
            ),   
            array(
               'type' => 'textarea',
               "holder" => "div",
               "class" => "",
               'heading' => 'Social Network',
               'param_name' => 'socials',
               "value" => "",
               "description" => __("Add Your Social HTML Code", 'otvcp-i10n')
            ),      
         )                
      ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Height Map", 'otvcp-i10n'),
         "param_name" => "height",
         "value" => 480,
         "description" => __("Please enter number height Map, 300, 350, 380, ..etc. Default: 420.", 'otvcp-i10n')
      ),    
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Zoom Map", 'otvcp-i10n'),
         "param_name" => "zoommap",
         "value" => 12,
         "description" => __("Please enter Zoom Map, Default: 15", 'otvcp-i10n')
      ),           
      array(
         "type" => "attach_image",
         "holder" => "div",
         "class" => "",
         "heading" => "Icon Map marker",
         "param_name" => "iconmap",
         "value" => "",
         "description" => __("Icon Map marker, 85 x 85", 'otvcp-i10n')
      ),    
      array(
        "type" => "dropdown",
        "heading" => __('Select map style', 'otvcp-i10n'),
        "param_name" => "style",
        "value" => array(   
                     __('Map Default', 'otvcp-i10n') => 'default',
                     __('Customize Gmap Style', 'otvcp-i10n') => 'customize_gmap',                 
                    ),
        "description" => __("Select amp style dark or light or custom map.", 'otvcp-i10n'),      
      ), 
      array(
         "type" => "textarea_raw_html",
         "holder" => "div",
         "class" => "",
         "heading" => esc_html__('JavaScript Code', 'otvcp-i10n'),
         "param_name" => "gmap_custom_style",
         "value" => "",
         "description" => __('Enter your JavaScript code, find your custom style gmap here:<a href="https://snazzymaps.com/explore" target="_blank">view more</a>', 'archi'),   
         "dependency"  => array( 'element' => 'style', 'value' => 'customize_gmap' ),   
      ), 
      array(
        "type" => "dropdown",
        "holder" => "div",
        "class" => "",
        "heading" => __('Tabs columns', 'otvcp-i10n'),
        "param_name" => "columns",
        "value" => array(   
                     __('2 Columns', 'otvcp-i10n') => '2col',
                     __('3 Columns', 'otvcp-i10n') => '3col',  
                     __('4 Columns', 'otvcp-i10n') => '4col', 
                     __('6 Columns', 'otvcp-i10n') => '6col',
                    ),
        "description" => __("Select number columns per row for tabs.", 'otvcp-i10n'),      
      ),    
    )));
}