<?php 
// Custom Heading
add_shortcode('heading','heading_func');
function heading_func($atts, $content = null){
	extract(shortcode_atts(array(			
		'align'		=>	'',	
	), $atts));
	ob_start(); ?>

	<div class="text-<?php echo esc_attr($align); ?>">
        <h2 class="heading wow fadeInUp" data-wow-delay="0"><?php echo htmlspecialchars_decode($content); ?></h2>
        <div class="small-border wow flipInY" data-wow-delay=".2s" data-wow-duration=".8s"></div>
    </div>	
	
<?php
    return ob_get_clean();
}

// Custom Heading 2
add_shortcode('heading2','heading2_func');
function heading2_func($atts, $content = null){
	extract(shortcode_atts(array(			
		'align'		=>	'left',	
		'title' 	=>	'',	
		'style' 	=>	'style1',		
		'extra_class' => ''
	), $atts));
	ob_start(); ?>

	<div class="text-<?php echo esc_attr($align); ?> <?php echo esc_attr($extra_class); ?>">
		<?php if ($style == 'style2'){ ?>			
			<?php if($title != ''){ ?> <h2><?php echo htmlspecialchars_decode($title); ?></h2><?php } ?>
			<div class="divider-deco"><span></span></div>
	        <?php if($content != ''){ ?><p class="lead"><?php echo htmlspecialchars_decode($content); ?></p><?php } ?>
		<?php }elseif($style == 'style3'){ ?>
            <?php if($title != ''){ ?> <h3><?php echo htmlspecialchars_decode($title); ?></h3><?php } ?>
            <div class="tiny-border thin"></div>
		<?php }else{ ?> 
			<?php if($title != ''){ ?> <h2><?php echo htmlspecialchars_decode($title); ?></h2><?php } ?>
	        <?php if($content != ''){ ?><p class="lead"><?php echo htmlspecialchars_decode($content); ?></p><?php } ?>
			<div class="divider-deco"><span></span></div>			
		<?php } ?>
    </div>	
	
<?php
    return ob_get_clean();
}

// Home Parallax Image
add_shortcode('home_parallax', 'home_parallax_func');
function home_parallax_func($atts, $content = null){
	extract(shortcode_atts(array(
		'bg_image'	=>  '',		
		'title'	=>  '',
		'stitle'	=>  '',
		'linkbox'	=>  '',
		'extra_class'	=>  '',	
		'titles'  => '',
	), $atts));	
	$titles = (array) vc_param_group_parse_atts( $titles );
	$url = vc_build_link( $linkbox );
	$url_image = wp_get_attachment_image_src($bg_image, ''); 
	$image_src = $url_image[0];
	ob_start(); 
?>	

	<article id="section-intro" class="no-padding autoheight light-text <?php echo esc_attr($extra_class); ?>" <?php if($bg_image != ''){ ?> style="background-image:url('<?php echo esc_url($image_src); ?>');" <?php } ?> data-stellar-background-ratio="0.5">
        <div class="center-y">
            <div class="inner text-center">
            	<?php if($title != ''){ ?>
                	<div class="sub-intro-text"><span><?php echo htmlspecialchars_decode($title); ?></span></div>
                <?php }  ?>	
                
                <?php if($stitle != ''){ ?>
                	<div class="divider-single"></div>
                	<h1><span class="id-color"><?php echo htmlspecialchars_decode($stitle); ?></span></h1>
                <?php }else{echo '<div class="divider-double"></div>';} ?>

                <div class="type-wrap title big">
                    <div class="typed-strings">
						<?php 
							foreach ( $titles as $data ) {
							$data['title'] = isset( $data['title'] ) ? $data['title'] : '';
						?>
							<p><?php echo esc_attr( $data['title'] ); ?></p>     
						<?php } ?>
                    </div>
                    <span class="typed"></span>
                </div>

                <?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {
					echo '<div class="divider-single"></div><a href="' . esc_attr( $url['url'] ) . '" class="btn-custom" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) . '</a>';
				} ?> 

                <div class="divider-double"></div>
            </div>
        </div>
    </article>
    
<?php
    return ob_get_clean();
}

// Home Parallax Image 2
add_shortcode('home_parallax2', 'home_parallax2_func');
function home_parallax2_func($atts, $content = null){
	extract(shortcode_atts(array(	
		'title'	=>  '',
		'stitle'	=>  '',
		'linkbox'	=>  '',			
	), $atts));	
	$url = vc_build_link( $linkbox ); 
	ob_start(); 
?>	
	
    <div class="center-y">
        <div class="inner">
        	<div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-ultra-big wow fadeInRight" data-wow-duration="1.5s">
                            <?php if($title != ''){ ?><span class="id-color"><?php echo htmlspecialchars_decode($title); ?></span><br><?php }  ?>
                            <?php if($stitle != ''){ ?><?php echo htmlspecialchars_decode($stitle); ?><?php }  ?>	
						</h1>
						<?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {
							echo '<a href="' . esc_attr( $url['url'] ) . '" class="btn btn-custom wow fadeInUp" data-wow-duration="2s" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) . '</a>';
						} ?> 
                    </div>
                    <div class="divider-double"></div>
                </div>
            </div>
        </div>
    </div>
    
<?php
    return ob_get_clean();
}

// Home HTML5 video
add_shortcode('home_html5_video', 'home_html5_video_func');
function home_html5_video_func($atts, $content = null){
	extract(shortcode_atts(array(	
		'title'	=>  '',
		'mp4'	=>  '',
		'webm'	=>  '',
		'bg_image'	=>  '',	
		'thumbnail_image'	=>  '',				
	), $atts));	
	$url_bgimage = wp_get_attachment_image_src($bg_image, ''); 
	$bgimage_src = $url_bgimage[0];

	$url_thumb = wp_get_attachment_image_src($thumbnail_image, ''); 
	$thumb_src = $url_thumb[0];
	ob_start(); 
?>	
	<div class="de-video-container autoheight no-padding">
		<div class="center-y absolute w100p h100p">
	        <div class="inner">
	            <div class="container">
	                <div class="row">
	                    <div class="col-md-12 text-center">
	                        <img src="<?php echo esc_url($thumb_src); ?>" alt="" />
							<div class="divider-double"></div>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
		
		<div class="bg-overlay overlaydark80"></div>	
		<!-- HTML5 Video Code -->
		<video autoplay="autoplay" loop="loop" autobuffer="autobuffer" muted="muted" poster="<?php echo esc_url($bgimage_src); ?>" width="640" height="360">
			<?php if($mp4 != ''){ ?><source src="<?php echo esc_url($mp4); ?>" type="video/mp4" /><?php } ?>
			<?php if($webm != ''){ ?><source src="<?php echo esc_url($webm); ?>" type="video/webm" /><?php } ?>
		</video>
	</div>
    
<?php
    return ob_get_clean();
}

// Call To Action
add_shortcode('cta_button','cta_button_func');
function cta_button_func($atts, $content = null){
	extract(shortcode_atts(array(
		'title'	    =>  '',
		'stitle'	=>  '',
		'btnlink'	=>  '',	
		'css'	    =>  '',
		'extra_class' =>  '',
	), $atts));
	$url = vc_build_link( $btnlink );
	ob_start(); ?>

	<div class="call-to-action text-light <?php echo vc_shortcode_custom_css_class( $css ) . ' ' . $extra_class; ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                	<?php if($title != ''){ ?>
	                	<h2><?php echo htmlspecialchars_decode($title); ?><?php if($stitle != ''){ ?><span><?php echo htmlspecialchars_decode($stitle); ?></span><?php } ?></h2>
	                <?php }  ?>		                	                                    
                </div>

                <div class="col-md-3">
                    <?php if ( strlen( $btnlink ) > 0 && strlen( $url['url'] ) > 0 ) {
						echo '<a class="btn-border-light" href="' . esc_attr( $url['url'] ) . '" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) . '</a>';
					} ?>
                </div>
            </div>
        </div>
    </div>
	
<?php
    return ob_get_clean();
}	

// Call To Action 2 use on preview 3
add_shortcode('cta_button2','cta_button2_func');
function cta_button2_func($atts, $content = null){
	extract(shortcode_atts(array(
		'title'	    =>  '',
		'btnlink'	=>  '',	
		'css'	    =>  '',
		'extra_class' =>  '',
	), $atts));
	$url = vc_build_link( $btnlink );
	ob_start(); ?>

    <div class="padding30 overlaydark80 wow fadeIn <?php echo vc_shortcode_custom_css_class( $css ) . ' ' . $extra_class; ?>">
    	<div class="row">
    		<div class="col-md-10">
	        	<?php if($title != ''){ ?>
	            	<h2 class="mb0 mt10"><?php echo htmlspecialchars_decode($title); ?><?php if($stitle != ''){ ?><span><?php echo htmlspecialchars_decode($stitle); ?></span><?php } ?></h2>
	            <?php }  ?>		                	                                    
	        </div>

	        <div class="col-md-2">
	            <?php if ( strlen( $btnlink ) > 0 && strlen( $url['url'] ) > 0 ) {
					echo '<a class="btn btn-custom" href="' . esc_attr( $url['url'] ) . '" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) . '</a>';
				} ?>
	        </div>
    	</div>
    </div>          
	
<?php
    return ob_get_clean();
}	

// Buttons
add_shortcode('button', 'button_func');
function button_func($atts, $content = null){
	extract(shortcode_atts(array(
		'btnlink' 	=> '',
		'style'     => 1,
	), $atts));
	$url = vc_build_link( $btnlink );
	$btnclass = '';
	if($style == 2){
		$btnclass = 'btn btn-custom';
	}elseif($style == 3){
		$btnclass = 'btn-arrow id-color';
	}else{
		$btnclass = 'btn-border-light';
	}
	ob_start(); 
?>			
	<?php 
		if($style == 3){
			if ( strlen( $btnlink ) > 0 && strlen( $url['url'] ) > 0 ) {
				echo '<a class=" '. $btnclass .' " href="' . esc_attr( $url['url'] ) . '" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '"><span class="line"></span><span class="url">' . esc_attr( $url['title'] ) . '</span></a>';
			} 
		}else{
			if ( strlen( $btnlink ) > 0 && strlen( $url['url'] ) > 0 ) {
					echo '<a class=" '. $btnclass .' " href="' . esc_attr( $url['url'] ) . '" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) . '</a>';
			} 
		}
	?>
	
<?php 
	return ob_get_clean();
}

// Commitment
add_shortcode('commitment_box', 'commitment_box_func');
function commitment_box_func($atts, $content = null){
	extract(shortcode_atts(array(	
		'title' 	=> '',			
		'css' 	=> '',
		'image_url' => '',	
		'extra_class' => ' bg-1 light-text'	
	), $atts));	
	$url_image = wp_get_attachment_image_src($image_url, ''); 
	$image_src = $url_image[0];
	ob_start(); 
?>			
	<div class="<?php echo vc_shortcode_custom_css_class( $css ) . ' ' . esc_attr($extra_class); ?> " <?php if($image_url != ''){ ?> style="background-image:url('<?php echo esc_url($image_src); ?>');" <?php } ?> >
        <div class="inner-padding">
            <h2 class="id-color"><?php echo esc_attr($title); ?></h2>
            <div class="tiny-border"></div>
            <?php echo htmlspecialchars_decode($content); ?>
        </div>
    </div>
    
<?php 
	return ob_get_clean();
}

// Awards Gallery
add_shortcode('awards','awards_func');
function awards_func($atts, $content = null){
	extract(shortcode_atts(array(
		'gallery'		=> 	'',
		'visible'		=> 	'3',
		'navigation'    => 	'yes',
	), $atts));
	$visible1 = (!empty($visible) ? esc_attr($visible) : 3);
	$id = uniqid( 'awards-carousel-' );
	ob_start(); ?>

	<?php if($navigation == 'yes'){ ?>
		<div class="owl-custom-nav">
	        <a class="btn-prev"></a>
	        <a class="btn-next"></a>
	    </div>
	<?php } ?>
    <ul id="<?php echo esc_attr($id); ?>" class="awards-carousel">
        <?php 
			$img_ids = explode(",",$gallery);
			foreach( $img_ids AS $img_id ){
			$meta = wp_prepare_attachment_for_js($img_id);
			$caption = $meta['caption'];
			$title = $meta['title'];	
			$description = $meta['description'];
			$image_src = wp_get_attachment_image_src($img_id,''); 
		?>
            <li class="item">
                <div class="overlay">
                    <h3><?php echo esc_attr($title); ?></h3>
                    <h4><?php echo esc_attr($description); ?></h4>
                </div>
                <img src="<?php echo esc_url( $image_src[0] ); ?>" alt="<?php echo esc_attr($title); ?>">
            </li>
        <?php } ?>
    </ul>

    <script type="text/javascript">
    	jQuery(document).ready(function() {		
			'use strict';
			jQuery("#<?php echo esc_attr($id); ?>").owlCarousel({
		        items: <?php echo esc_attr($visible1); ?>,
		        navigation: false,
		        pagination: false,
		    });
		});
    </script>
	
<?php 
	return ob_get_clean();
}

// Image Slider
add_shortcode('img_slider','img_slider_func');
function img_slider_func($atts, $content = null){
	extract(shortcode_atts(array(
		'gallery'		=> 	'',
	), $atts));
	ob_start(); ?>

	<div class="owl-custom-nav">
        <a class="btn-prev"></a>
        <a class="btn-next"></a>
    </div>

    <div class="single-carousel-arrow-nav">
    	<?php 
			$img_ids = explode(",",$gallery);
			foreach( $img_ids AS $img_id ){
			$meta = wp_prepare_attachment_for_js($img_id);
			$caption = $meta['caption'];
			$title = $meta['title'];	
			$description = $meta['description'];
			$image_src = wp_get_attachment_image_src($img_id,''); 
		?>
        <img src="<?php echo esc_url( $image_src[0] ); ?>" alt="<?php echo esc_attr($title); ?>">
        <?php } ?>
    </div>   
	
<?php 
	return ob_get_clean();
}

// History TimeLine Post
add_shortcode('history_post','history_post_func');
function history_post_func($atts, $content = null){
	extract(shortcode_atts(array(
		'number'	=>		'',
	), $atts));
	$number1 = (!empty($number) ? $number : -1);
	ob_start(); 
?>
	
	<div class="divider-single"></div>
    <ul class="timeline-year">
        <?php
            $counter = 0;
            $ref_month = '';
            $monthly = new WP_Query(array(
            	'post_type' => 'history',
                'posts_per_page' => $number1
            ));
            if( $monthly->have_posts() ) : while( $monthly->have_posts() ) : $monthly->the_post();				
		?>			        
        	<?php 
            if( get_the_date('mY') != $ref_month ) {
                if( $ref_month );
	        ?>
	        <li>
			<!-- year -->
			<div class="num"><?php echo get_the_date('Y'); ?></div>
			<?php
	            $ref_month = get_the_date('mY');
	            $counter = 0;
	            }
			?> 
            <div class="post">
                <?php the_post_thumbnail( 'full', array( 'class' => 'pull-left' ) ); ?><h4><span class="date"><?php the_time('F, j'); ?></span> <?php the_title(); ?></h4>
                <?php the_content() ?>
            </div>           
        	<div class="clearfix"></div>
       	</li>
        <?php endwhile; wp_reset_postdata(); endif; ?>	
    </ul>
    <div class="divider-double"></div>

<?php
    return ob_get_clean();
}

// Careers Post List
add_shortcode('career_post','career_post_func');
function career_post_func($atts, $content = null){
	extract(shortcode_atts(array(
		'number'	=>		'',
		'idcate_career' => '',
	), $atts));
	$number1 = (!empty($number) ? $number : 3);
	ob_start(); 
?>
	<ul class="list-thumbnail">
		<?php
			if ($idcate_career != '') {
	    		$args = array(
					'tax_query' => array(
						array(
							'taxonomy' => 'category_career',
							'field' => 'slug',
							'terms' => explode(',',$idcate_career)
						),
					),
					'post_type' => 'career',
					'showposts' => $number1,
				);
	    	}else{
	        	$args = array(
					'post_type' => 'career',
					'showposts' => $number1,
				);
	        }
			$career = new WP_Query($args);
			if($career->have_posts()) : while($career->have_posts()) : $career->the_post();
			$business = get_post_meta(get_the_ID(),'_cmb_business_sector', true);
			$end_date = get_post_meta(get_the_ID(),'_cmb_end_date', true);
			$description = get_post_meta(get_the_ID(),'_cmb_desc_career', true);
		?>
        <li>
            <?php the_post_thumbnail(); ?> 
            <div class="text">
                <a href="<?php the_permalink(); ?>">
                    <h4><?php the_title(); ?></h4>
                </a>
                <p><?php echo esc_attr($description); ?></p>
            </div>
        </li>
        <?php endwhile; wp_reset_postdata(); endif; ?>	
    </ul>

<?php
    return ob_get_clean();
}

// Careers Post List 2
add_shortcode('career_post2','career_post2_func');
function career_post2_func($atts, $content = null){
	extract(shortcode_atts(array(
		'number'	=>		'',
		'idcate_career' => '',
	), $atts));
	$number1 = (!empty($number) ? $number : 3);
	ob_start(); 
?>
	<div class="list-careers">
		<?php
			if ($idcate_career != '') {
	    		$args = array(
					'tax_query' => array(
						array(
							'taxonomy' => 'category_career',
							'field' => 'slug',
							'terms' => explode(',',$idcate_career)
						),
					),
					'post_type' => 'career',
					'showposts' => $number1,
				);
	    	}else{
	        	$args = array(
					'post_type' => 'career',
					'showposts' => $number1,
				);
	        }
			$career2 = new WP_Query($args);
			if($career2->have_posts()) : while($career2->have_posts()) : $career2->the_post();
			$business = get_post_meta(get_the_ID(),'_cmb_business_sector', true);
			$end_date = get_post_meta(get_the_ID(),'_cmb_end_date', true);
			$description = get_post_meta(get_the_ID(),'_cmb_desc_career', true);
			$link_apply = get_post_meta(get_the_ID(),'_cmb_link_apply', true);
		?>
		<div class="expand-box">
            <div class="inner">
                <span class="btn-expand"></span>
                <div class="row">
                    <div class="col-md-6">
                        <?php the_post_thumbnail('career-thumb', array('class' => 'pull-left')); ?>
                        <h4><?php the_title(); ?></h4>
                        <?php echo esc_attr($description); ?>
                    </div>
                    <div class="col-md-3">
                        <div class="divider"></div>
                        <strong><?php esc_html_e('Business Sector:', 'otvcp-i10n'); ?></strong><br>
                        <?php echo esc_attr($business); ?>
                    </div>
                    <div class="col-md-3">
                        <div class="divider"></div>
                        <strong><?php esc_html_e('End Date:', 'otvcp-i10n'); ?></strong><br>
                        <span class="id-color"><?php echo esc_attr($end_date); ?></span>
                    </div>


                    <div class="hide-content">
                        <div class="divider-single"></div>
                        <?php the_content(); ?>
                    </div>
                </div>
            </div>
            <?php if ($link_apply != '') { ?>
            	<a href="<?php echo esc_url($link_apply); ?>" class="btn-custom btn-fullwidth"><?php esc_html_e('Apply Now', 'otvcp-i10n'); ?></a>
            <?php } ?>            
        </div>
        <?php endwhile; wp_reset_postdata(); endif; ?>	
    </div>

<?php
    return ob_get_clean();
}

// Founder & Directors Post
add_shortcode('founder_directors','founder_directors_func');
function founder_directors_func($atts, $content = null){
	extract(shortcode_atts(array(
		'number'	=>		'',
	), $atts));
	$number1 = (!empty($number) ? $number : 3);
	ob_start(); 
?>	

	<div class="owl-custom-nav">
        <a class="btn-next"></a>
        <a class="btn-prev"></a>
    </div>

    <ul class="single-carousel-arrow-nav">
    	<?php
			$args = array(
				'post_type' => 'founder',
				'posts_per_page' => $number1,
			);
			$founder = new WP_Query($args);
			if($founder->have_posts()) : while($founder->have_posts()) : $founder->the_post();
			$job_founder = get_post_meta(get_the_ID(),'_cmb_job_founder', true);			
		?>
        <li>
            <div class="inner">
                <?php the_post_thumbnail('full', array('class' => 'pull-left')); ?>
                <div class="text">
                    <span class="name"><?php the_title(); ?></span>
                    <span class="position"><?php echo esc_attr($job_founder); ?></span>
                    <p><?php echo get_the_excerpt(); ?></p>
                </div>

                <div class="clearfix"></div>
            </div>
        </li>
        <?php endwhile; wp_reset_postdata(); endif; ?>	
    </ul>

<?php
    return ob_get_clean();
}

// Testimonial Silder
add_shortcode('testslide','testslide_func');
function testslide_func($atts, $content = null){
	extract(shortcode_atts(array(
		'visible'	=>		'',
		'number'	=>		'',
		'idcate_testimonials' => '',
	), $atts));
		$visible1 = (!empty($visible) ? esc_attr($visible) : 1);
		$number1 = (!empty($number) ? esc_attr($number) : 4);
		$id = uniqid( 'testi-carousel-' );
	ob_start(); 
?>
	
    <div id="<?php echo esc_attr($id); ?>" class="testi-slider testi-carousel wow fadeIn" data-wow-delay="0s" data-wow-duration="1s">
        <?php
			if ($idcate_testimonials != '') {
	    		$args = array(
					'tax_query' => array(
						array(
							'taxonomy' => 'category_testimonial',
							'field' => 'slug',
							'terms' => explode(',',$idcate_testimonials)
						),
					),
					'post_type' => 'testimonial',
					'showposts' => $number1,
				);
	    	}else{
	        	$args = array(
					'post_type' => 'testimonial',
					'showposts' => $number1,
				);
	        }
			$testimonial = new WP_Query($args);
			if($testimonial->have_posts()) : while($testimonial->have_posts()) : $testimonial->the_post();
			$job = get_post_meta(get_the_ID(),'_cmb_job_testi', true);
		?>
            <div class="item">
                <blockquote>
                    <?php the_content(); ?>
                </blockquote>
                <span class="testi-by"><?php the_title(); ?></span>
            </div>
        <?php endwhile; wp_reset_postdata(); endif; ?>
    </div>
    <script type="text/javascript">
    	jQuery(document).ready(function() {		
			'use strict';
			jQuery("#<?php echo esc_attr($id); ?>").owlCarousel({
			    items : <?php echo esc_attr($visible1); ?>,
				itemsDesktop : [1199,1],
				itemsDesktopSmall : [980,1],
			    itemsTablet: [768,1],
			    itemsTabletSmall: false,
			    itemsMobile : [479,1],
			    navigation : false,
				autoHeight : true,
		    });
		});
    </script>
	                
<?php
    return ob_get_clean();
}

// Testimonial Silder 2
add_shortcode('testslide2','testslide2_func');
function testslide2_func($atts, $content = null){
	extract(shortcode_atts(array(
		'number'	=>		'',
		'idcate_testimonials' => '',
	), $atts));
		$number1 = (!empty($number) ? esc_attr($number) : 4);
		$id = uniqid( 'testi-carousel2-' );
	ob_start(); 
?>
	
	<div id="<?php echo esc_attr($id); ?>" class="testi-slider testi-carousel-2 wow fadeIn" data-wow-delay="0s" data-wow-duration="1s">
    	<?php
			if ($idcate_testimonials != '') {
	    		$args = array(
					'tax_query' => array(
						array(
							'taxonomy' => 'category_testimonial',
							'field' => 'slug',
							'terms' => explode(',',$idcate_testimonials)
						),
					),
					'post_type' => 'testimonial',
					'showposts' => $number1,
				);
	    	}else{
	        	$args = array(
					'post_type' => 'testimonial',
					'showposts' => $number1,
				);
	        }
			$testimonial2 = new WP_Query($args);
			if($testimonial2->have_posts()) : while($testimonial2->have_posts()) : $testimonial2->the_post();
			$job = get_post_meta(get_the_ID(),'_cmb_job_testi', true);
			$company = get_post_meta(get_the_ID(),'_cmb_company_testi', true);
		?>
            <div class="item">
                <blockquote>
                    <?php the_content(); ?>
                </blockquote>
                <div class="arrow-down"></div>
                <div class="testi-by">
                	<?php the_post_thumbnail('full', array('class' => 'img-circle')); ?> 
                	<span class="name">
                    	<strong><?php the_title(); ?></strong>, <?php if($job != ''){ echo esc_attr($job); ?><br>
                        <?php } echo esc_attr($company); ?>
                    </span>
            	</div>
            </div>
        <?php endwhile; wp_reset_postdata(); endif; ?>
    </div>

    <script type="text/javascript">
    	jQuery(document).ready(function () { 
			'use strict'; // use strict mode
			jQuery("#<?php echo esc_attr($id); ?>").owlCarousel({
		        singleItem: true,
		        lazyLoad: true,
		        navigation: false,
		        pagination: true
		    });
		});	
    </script>
	                
<?php
    return ob_get_clean();
}

// Testimonial Silder 3
add_shortcode('testslide3','testslide3_func');
function testslide3_func($atts, $content = null){
	extract(shortcode_atts(array(
		'number'	=>		'',
		'idcate_testimonials' => '',
	), $atts));
		$number1 = (!empty($number) ? esc_attr($number) : 4);
		$id = uniqid( 'testi-carousel3-' );
	ob_start(); 
?>

	<ul id="<?php echo esc_attr($id); ?>" class="client-quotes text-white nav-s1">
		<?php
			if ($idcate_testimonials != '') {
	    		$args = array(
					'tax_query' => array(
						array(
							'taxonomy' => 'category_testimonial',
							'field' => 'slug',
							'terms' => explode(',',$idcate_testimonials)
						),
					),
					'post_type' => 'testimonial',
					'showposts' => $number1,
				);
	    	}else{
	        	$args = array(
					'post_type' => 'testimonial',
					'showposts' => $number1,
				);
	        }
			$testimonial2 = new WP_Query($args);
			if($testimonial2->have_posts()) : while($testimonial2->have_posts()) : $testimonial2->the_post();
			$job = get_post_meta(get_the_ID(),'_cmb_job_testi', true);
			$company = get_post_meta(get_the_ID(),'_cmb_company_testi', true);
		?>
	        <li>
	            <div class="text">
	                <?php the_content(); ?>
	            </div>
	            <span class="name"><?php the_title(); ?></span>
	            <span class="company"><?php if($job != ''){ echo esc_attr($job); ?><?php } ?><?php echo esc_attr($company); ?></span>
	        </li>
	    <?php endwhile; wp_reset_postdata(); endif; ?>    
    </ul>
    <div class="clearfix"></div>

    <script type="text/javascript">
    	jQuery(document).ready(function () { 
			'use strict'; // use strict mode
			jQuery("#<?php echo esc_attr($id); ?>").owlCarousel({
		        singleItem: true,
		        lazyLoad: false,
		        navigation: false,
		        pagination: true
		    });
		});	
    </script>
	                
<?php
    return ob_get_clean();
}

// Testimonial Grid
add_shortcode('testgrid','testgrid_func');
function testgrid_func($atts, $content = null){
	extract(shortcode_atts(array(
		'number'	=>		'',
		'testi_columns'    =>   2,
		'idcate_testimonials' => '',
	), $atts));
	$number1 = (!empty($number) ? $number : 4);
	ob_start(); 
?>
	
	<div id="testimonial-masonry" class="masonry row">
		<?php
			if ($idcate_testimonials != '') {
	    		$args = array(
					'tax_query' => array(
						array(
							'taxonomy' => 'category_testimonial',
							'field' => 'slug',
							'terms' => explode(',',$idcate_testimonials)
						),
					),
					'post_type' => 'testimonial',
					'showposts' => $number1,
				);
	    	}else{
	        	$args = array(
					'post_type' => 'testimonial',
					'showposts' => $number1,
				);
	        }
			$testimonial3 = new WP_Query($args);
			if($testimonial3->have_posts()) : while($testimonial3->have_posts()) : $testimonial3->the_post();
			$job = get_post_meta(get_the_ID(),'_cmb_job_testi', true);
			$company = get_post_meta(get_the_ID(),'_cmb_company_testi', true);
		?>
			<div class="<?php if ($testi_columns == 2) {echo 'col-md-6'; }elseif ($testi_columns == 3) { echo 'col-md-4'; }else{echo 'col-md-3';} ?> item">
				<div class="testi-box-1">
                    <blockquote>
                        <?php the_content(); ?>
                    </blockquote>
                    <div class="arrow-down"></div>
                    <div class="testi-by">
                    	<?php the_post_thumbnail('full', array('class' => 'img-circle')); ?> 
                    	<span class="name">
	                    	<strong><?php the_title(); ?></strong>, <?php if($job != ''){ echo esc_attr($job); ?><br>
	                        <?php } echo esc_attr($company); ?>
                        </span>
                	</div>
                </div>
			</div>     
		<?php endwhile; wp_reset_postdata(); endif; ?>		
	</div>

<?php
    return ob_get_clean();
}

// Gallery Image
add_shortcode('gocargo_gallery', 'gocargo_gallery_func');
function gocargo_gallery_func($atts, $content = null){
	extract(shortcode_atts(array(		
		'gallery'		=> 	'',
		'gallery_columns'   => 	4,
	), $atts));
	$id = uniqid( 'zoom-gallery-' );

	ob_start(); ?>        		

    <div class="gallery full-gallery ex-gallery <?php echo esc_attr($id); ?> pf_full_width <?php if ($gallery_columns == 2) {echo 'pf_2_cols'; }elseif ($gallery_columns == 3) { echo 'pf_3_cols'; }else{} ?>">
        <?php 
			$img_ids = explode(",",$gallery);
			foreach( $img_ids AS $img_id ){
			$meta = wp_prepare_attachment_for_js($img_id);
			$caption = $meta['caption'];
			$title = $meta['title'];	
			$description = $meta['description'];
			$image_src = wp_get_attachment_image_src($img_id,''); 
		?>
	        <div class="item">
	            <div class="picframe">
	                <a href="<?php echo esc_url( $image_src[0] ); ?>" data-source="<?php echo esc_url( $image_src[0] ); ?>" title="<?php echo esc_attr($title); ?>">
	                    <span class="overlay"></span>
	                    <span class="pf_text">
	                        <span class="project-name"><?php echo esc_attr($title); ?></span>
	                        <span class="small-border"></span>
	                    </span>
	                    <img src="<?php echo esc_url( $image_src[0] ); ?>" alt="" />
	                </a>
	            </div>
	        </div>
        <?php } ?>	
    </div>
    <script type="text/javascript">
	    (function($) { "use strict";
			jQuery(document).ready(function () {
			    'use strict'; // use strict mode
		    	jQuery('.<?php echo esc_attr($id); ?>').magnificPopup({
			        delegate: 'a',
			        type: 'image',
			        closeOnContentClick: false,
			        closeBtnInside: false,
			        mainClass: 'mfp-with-zoom mfp-img-mobile',
			        image: {
			            verticalFit: true,
			            titleSrc: function (item) {
			                //return item.el.attr('title') + ' &middot; <a class="image-source-link" href="'+item.el.attr('data-source')+'" target="_blank">image source</a>';
			                return item.el.attr('title');
			            }
			        },
			        gallery: {
			            enabled: true
			        },
			        zoom: {
			            enabled: true,
			            duration: 300, // don't foget to change the duration also in CSS
			            opener: function (element) {
			                return element.find('img');
			            }
			        }
			    });
		    });
		})(jQuery); 
    </script>
<?php
    return ob_get_clean();
}

// Gallery Image 2
add_shortcode('gocargo_gallery2', 'gocargo_gallery2_func');
function gocargo_gallery2_func($atts, $content = null){
	extract(shortcode_atts(array(		
		'gallery'		=> 	'',
		'gallery_columns'   => 	4,
	), $atts));
	$id = uniqid( 'zoom-gallery-' );

	ob_start(); ?>        		

    <div class="gallery full-gallery ex-gallery <?php echo esc_attr($id); ?> pf_full_width <?php if ($gallery_columns == 2) {echo 'col-2'; }elseif ($gallery_columns == 3) { echo 'col-3'; }else{echo 'col-4';} ?>">
        <?php 
			$img_ids = explode(",",$gallery);
			foreach( $img_ids AS $img_id ){
			$meta = wp_prepare_attachment_for_js($img_id);
			$caption = $meta['caption'];
			$title = $meta['title'];	
			$description = $meta['description'];
			$image_src = wp_get_attachment_image_src($img_id,''); 
		?>
	        <div class="item">
	            <div class="picframe">
	                <a href="<?php echo esc_url( $image_src[0] ); ?>" data-source="<?php echo esc_url( $image_src[0] ); ?>" title="<?php echo esc_attr($title); ?>">
	                    <span class="overlay"></span>
	                    <span class="pf_text">
	                        <span class="project-name"><?php echo esc_attr($title); ?></span>
	                        <span class="small-border"></span>
	                    </span>
	                    <img src="<?php echo esc_url( $image_src[0] ); ?>" alt="" />
	                </a>
	            </div>
	        </div>
        <?php } ?>	
    </div>
    <script type="text/javascript">
	    (function($) { "use strict";
			jQuery(document).ready(function () {
			    'use strict'; // use strict mode
		    	jQuery('.<?php echo esc_attr($id); ?>').magnificPopup({
			        delegate: 'a',
			        type: 'image',
			        closeOnContentClick: false,
			        closeBtnInside: false,
			        mainClass: 'mfp-with-zoom mfp-img-mobile',
			        image: {
			            verticalFit: true,
			            titleSrc: function (item) {
			                //return item.el.attr('title') + ' &middot; <a class="image-source-link" href="'+item.el.attr('data-source')+'" target="_blank">image source</a>';
			                return item.el.attr('title');
			            }
			        },
			        gallery: {
			            enabled: true
			        },
			        zoom: {
			            enabled: true,
			            duration: 300, // don't foget to change the duration also in CSS
			            opener: function (element) {
			                return element.find('img');
			            }
			        }
			    });
		    });
		})(jQuery); 
    </script>
<?php
    return ob_get_clean();
}

// Gallery Slider Image
add_shortcode('gocargo_gallery_slider', 'gocargo_gallery_slider_func');
function gocargo_gallery_slider_func($atts, $content = null){
	extract(shortcode_atts(array(		
		'gallery'		=> 	'',
	), $atts));

	ob_start(); ?>   

	<div class="gallery-carousel nav-s1 wow fadeInUp">
		<?php 
			$img_ids = explode(",",$gallery);
			foreach( $img_ids AS $img_id ){
			$meta = wp_prepare_attachment_for_js($img_id);
			$caption = $meta['caption'];
			$title = $meta['title'];	
			$description = $meta['description'];
			$image_src = wp_get_attachment_image_src($img_id,''); 
		?>
	        <div class="gallery-item">
	            <a class="preview" href="<?php echo esc_url( $image_src[0] ); ?>" title="<?php echo esc_attr($title); ?>">
	            	<span class="overlay"><?php echo esc_attr($title); ?></span>
	            </a>
	            <img src="<?php echo esc_url( $image_src[0] ); ?>" alt="<?php echo esc_attr($title); ?>">
	        </div>
	    <?php } ?>
    </div>   
    
<?php
    return ob_get_clean();
}

// About us 
add_shortcode('about_box', 'about_box_func');
function about_box_func($atts, $content = null){
	extract(shortcode_atts(array(				
		'css' 	=> '',
		'icon' 	=> '',
		'title' 	=> '',
		'linkbox' 	=> '',
	), $atts));
	$url = vc_build_link( $linkbox );	
	ob_start(); 
?>			
	
	<div class="feature-box <?php echo vc_shortcode_custom_css_class( $css ); ?>">
        <i class="icon-<?php echo esc_attr($icon); ?> wow zoomIn" data-wow-delay="0s"></i>
        <div class="text wow fadeIn" data-wow-delay=".2s">
            <h3>
	            <?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {
					echo '<a href="' . esc_attr( $url['url'] ) . '" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">';
				} ?>  
					<?php echo esc_attr( $title ) ?>
				<?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {
					echo '</a>';
				} ?> 
			</h3>
            <?php echo htmlspecialchars_decode($content); ?>
        </div>
    </div>
    
<?php 
	return ob_get_clean();
}

// About us 2
add_shortcode('about_us2', 'about_us2_func');
function about_us2_func($atts, $content = null){
	extract(shortcode_atts(array(				
		'css' 	=> '',
		'photo' 	=> '',
		'title' 	=> '',
		'linkbox' 	=> '',
	), $atts));
	$url = vc_build_link( $linkbox );	
	$url_image = wp_get_attachment_image_src($photo, '');
	$alt = get_post_meta($photo, '_wp_attachment_image_alt', true); 
	$image_src = $url_image[0];
	ob_start(); 
?>			
	
	<div class="about-box2 <?php echo vc_shortcode_custom_css_class( $css ); ?>">
		<img src="<?php echo esc_url($image_src); ?>" class="img-responsive" alt="<?php echo esc_attr($alt); ?>">
        <div class="divider-single"></div>
        <h2><?php echo esc_attr( $title ) ?></h2>
        <div class="tiny-border"></div>
        <?php echo htmlspecialchars_decode($content); ?>
        <div class="button_box">
	        <?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {
				echo '<a href="' . esc_attr( $url['url'] ) . '" class="btn btn-custom
				" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) . '</a>';
			} ?>
		</div>
    </div>
    
<?php 
	return ob_get_clean();
}

// About us 3
add_shortcode('about_us3', 'about_us3_func');
function about_us3_func($atts, $content = null){
	extract(shortcode_atts(array(				
		'css' 	=> '',
		'photo' 	=> '',
		'title' 	=> '',
		'linkbox' 	=> '',
	), $atts));
	$url = vc_build_link( $linkbox );	
	$url_image = wp_get_attachment_image_src($photo, '');
	$alt = get_post_meta($photo, '_wp_attachment_image_alt', true); 
	$image_src = $url_image[0];
	ob_start(); 
?>			
	
	<div class="about-box3 <?php echo vc_shortcode_custom_css_class( $css ); ?>">
		<img src="<?php echo esc_url($image_src); ?>" class="img-responsive" alt="<?php echo esc_attr($alt); ?>">        
        <h3><?php echo esc_attr( $title ) ?></h3>        
        <?php echo htmlspecialchars_decode($content); ?>
        <div class="button_box">
	        <?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {
				echo '<a href="' . esc_attr( $url['url'] ) . '" class="btn btn-custom
				" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) . '</a>';
			} ?>
		</div>
    </div>
    
<?php 
	return ob_get_clean();
}

// About us 4 use on preview 3
add_shortcode('about_us4', 'about_us4_func');
function about_us4_func($atts, $content = null){
	extract(shortcode_atts(array(				
		'css' 	=> '',
		'icon_fontawesome' 	=> '',
		'title' 	=> '',
		'linkbox' 	=> '',
		'wowdelay'  => '.2',
	), $atts));
	$url = vc_build_link( $linkbox );	
	ob_start(); 
?>			
	<div class="marginbottom30 wow fadeInUp <?php echo vc_shortcode_custom_css_class( $css ); ?>" data-wow-delay="<?php echo esc_attr($wowdelay); ?>s">
        <div class="box-icon-small">
            <i class="<?php echo esc_attr($icon_fontawesome); ?>"></i>
            <div class="text">
                <h4><?php echo esc_attr( $title ) ?></h4>
                <p><?php echo htmlspecialchars_decode($content); ?></p>
                <div class="button_box">
			        <?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {
						echo '<a href="' . esc_attr( $url['url'] ) . '" class="btn btn-custom
						" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) . '</a>';
					} ?>
				</div>
            </div>
        </div>
    </div>
    
<?php 
	return ob_get_clean();
}

// About us 5 use on GoCargo Express
add_shortcode('about_us5', 'about_us5_func');
function about_us5_func($atts, $content = null){
	extract(shortcode_atts(array(				
		'css' 	=> '',
		'icon_fontawesome' 	=> '',
		'title' 	=> '',
		'linkbox' 	=> '',
		'icondelay'  => '1',
		'textdelay'  => '1',
		'borderbox'  => ''
	), $atts));
	$url = vc_build_link( $linkbox );	
	ob_start(); 
?>			
	<div class="feature-box <?php if($borderbox != 'no'){echo 'border';} ?> <?php echo vc_shortcode_custom_css_class( $css ); ?>">
        <i class="<?php echo esc_attr($icon_fontawesome); ?> icon-s1 wow zoomIn" data-wow-delay="<?php echo esc_attr($icondelay); ?>s"></i>
        <div class="text wow fadeIn" data-wow-delay="<?php echo esc_attr($textdelay); ?>s">
            <h4><?php echo esc_attr( $title ) ?></h4>
            <p><?php echo htmlspecialchars_decode($content); ?></p>                
	        <?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {				
				echo '<a href="' . esc_attr( $url['url'] ) . '" class="btn-arrow hover-light
				" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">
				<span class="line"></span><span class="url">' . esc_attr( $url['title'] ) . '</span></a>';				
			} ?>				
        </div>
    </div>    
<?php 
	return ob_get_clean();
}

// Services Grid
add_shortcode('service_grid','service_grid_func');
function service_grid_func($atts, $content = null){
	extract(shortcode_atts(array(
		'number'	=>		'',
		'service_columns'  =>  3,
		'idcate' => '',
		'btntext' => 'Read More',
		'show_hide_btn' => 'show'
	), $atts));
	$number1 = (!empty($number) ? $number : 3);
	ob_start(); 
?>

	<?php
		$i = 1;
		if($idcate != ''){
			$args = array(
				'tax_query' => array(
					array(
						'taxonomy' => 'category_service',
						'field' => 'slug',
						'terms' => explode(',',$idcate)
					),
				),
				'post_type' => 'service',
				'showposts' => $number1,
			);
		}else{
			$args = array(
				'post_type' => 'service',
				'posts_per_page' => $number1,
			);
		}
		$services = new WP_Query($args);
		if($services->have_posts()) : while($services->have_posts()) : $services->the_post();	
		if ($i%$service_columns==1) {
            echo '<div class="row-service">';
        }	
	?>
		
		<div style="background-image:url('<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id())); ?>');" class="service-table-cell <?php if ($service_columns == 2) {echo 'box-two-columns'; }elseif ($service_columns == 3) { echo 'box-one-third'; }elseif ($service_columns == 4) { echo 'box-four-columns'; }elseif ($service_columns == 5) { echo 'box-five-columns'; }else{echo 'box-six-columns';} ?> services-box light-text">
            <div class="inner wow" data-wow-delay="0s">
                <h2 class="wow fadeIn" data-wow-delay=".2s"><?php the_title(); ?></h2>
                <div class="wow fadeIn" data-wow-delay=".3s"><p><?php echo get_the_excerpt(); ?></p></div>
                <?php if ($show_hide_btn != 'hide') { ?>
	                <div class="divider-single"></div>
	                <a href="<?php the_permalink(); ?>" class="btn-border-light wow fadeInUp" data-wow-delay=".4s" data-wow-duration=".3s"><?php if($btntext != ''){echo esc_attr($btntext); }else{ _e('Read More', 'otvcp-i10n'); }  ?></a>
            	<?php } ?>
            </div>
        </div>
	<?php
        if ($i%$service_columns==0) {
            echo '</div>';
        }  
    ?>  
	<?php $i++; endwhile; wp_reset_postdata(); endif; ?>				

<?php
    return ob_get_clean();
}	

// Services Grid 2
add_shortcode('service_grid2','service_grid2_func');
function service_grid2_func($atts, $content = null){
	extract(shortcode_atts(array(
		'number'	=>		'',
		'service_columns'  =>  2,
		'idcate' => '',
		'btntext' => 'View Details',
		'show_hide_btn' => 'show'
	), $atts));
	$number1 = (!empty($number) ? $number : 2);
	ob_start(); 
?>
	<div class="row service-grid">
		<?php
			if($idcate != ''){
				$args = array(
					'tax_query' => array(
						array(
							'taxonomy' => 'category_service',
							'field' => 'slug',
							'terms' => explode(',',$idcate)
						),
					),
					'post_type' => 'service',
					'showposts' => $number1,
				);
			}else{
				$args = array(
					'post_type' => 'service',
					'posts_per_page' => $number1,
				);
			}
			$services = new WP_Query($args);
			if($services->have_posts()) : while($services->have_posts()) : $services->the_post();	
			$icon_service = get_post_meta(get_the_ID(),'_cmb_icon_service', true);	
		?>		
			<div class="item margin-bot-60 <?php if ($service_columns == 2) {echo 'col-md-6'; }elseif ($service_columns == 3) { echo 'col-md-4'; }else { echo 'col-md-3'; } ?>">
		        <div class="box-with-icon-left">
		            <i class="fa fa-<?php echo esc_attr($icon_service); ?> icon-big"></i>
		            <div class="text">
		                <h2><?php the_title(); ?></h2>
		                <p><?php echo get_the_excerpt(); ?></p>
		                <?php if ($show_hide_btn != 'hide') { ?>
			                <div class="divider-single"></div>
			                <a href="<?php the_permalink(); ?>" class="btn-text"><?php if($btntext != ''){echo esc_attr($btntext); }else{ _e('View Details', 'otvcp-i10n'); } ?></a>
		            	<?php } ?>
		            </div>
		        </div>
		    </div>		
		<?php endwhile; wp_reset_postdata(); endif; ?>				
	</div>
<?php
    return ob_get_clean();
}	

// Services 3
add_shortcode('service_grid3','service_grid3_func');
function service_grid3_func($atts, $content = null){
	extract(shortcode_atts(array(
		'title'	=>		'',
		'desc'	=>		'',
		'number'	=>		'',
		'service_columns'  =>  2,
		'css' =>     '',
		'idcate' => '',
		'btntext' => 'View Details',
		'show_hide_btn' => 'show'
	), $atts));
	$number1 = (!empty($number) ? esc_attr($number) : 4);
	ob_start(); 
?>
	<div class="<?php echo vc_shortcode_custom_css_class( $css ); ?>">			   
        <div class="inner-padding">
        <?php if ($title != '' || $desc != '' ) { ?>        
        	<h2><?php echo esc_attr($title); ?></h2>
            <p><?php echo esc_attr($desc); ?></p>
            <div class="divider-deco"><span></span></div>
        <?php } ?>    
            <div class="row">
            	<?php
            		$i=0;
            		$j=0;
					
					if($idcate != ''){
						$args = array(
							'tax_query' => array(
								array(
									'taxonomy' => 'category_service',
									'field' => 'slug',
									'terms' => explode(',',$idcate)
								),
							),
							'post_type' => 'service',
							'showposts' => $number1,
						);
					}else{
						$args = array(
							'post_type' => 'service',
							'posts_per_page' => $number1,
						);
					}
					
					$services = new WP_Query($args);
					if($services->have_posts()) : while($services->have_posts()) : $services->the_post(); $i++;	
					$icon_service = get_post_meta(get_the_ID(),'_cmb_icon_service', true);	
				?>
                    <div class="margin-bot-30 <?php if ($service_columns == 2) {echo 'col-md-6 col-sm-6'; }elseif ($service_columns == 3) { echo 'col-md-4'; }else { echo 'col-md-3'; } ?> wow fadeIn" data-wow-delay="<?php echo $j = $i*0.2; ?>s">
                        <div class="box-icon-small">
                            <i class="fa fa-<?php echo esc_attr($icon_service); ?>"></i>
                            <div class="text">
                                <h3><?php the_title(); ?></h3>
                                <p><?php echo gocargo_excerpt(8); ?></p>
                                <?php if ($show_hide_btn != 'hide') { ?>
                                	<a href="<?php the_permalink(); ?>" class="btn-arrow"><span class="line"></span><span class="url"><?php if($btntext != ''){echo esc_attr($btntext); }else{ _e('View Details', 'otvcp-i10n'); } ?></span></a>
                            	<?php } ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; wp_reset_postdata(); endif; ?>    
            </div>	                    
        </div>	           
	    <div class="clearfix"></div>
	</div> 
<?php
    return ob_get_clean();
}

// Service Box 4 use in preview 3
add_shortcode('service_grid4','service_grid4_func');
function service_grid4_func($atts, $content = null){
	extract(shortcode_atts(array(
		'title'	=>		'',
		'number'	=>		'',
		'service_columns'  =>  4,
		'idcate' => '',
		'service_style' => '',
		'btntext' => 'View Details',
		'show_hide_btn' => 'show'
	), $atts));
	$number1 = (!empty($number) ? esc_attr($number) : 4);	
	ob_start(); 
?>
			   
	<?php
		$i=0;
		$j=0;

		global $post;

		if($idcate != ''){
			$args = array(
				'tax_query' => array(
					array(
						'taxonomy' => 'category_service',
						'field' => 'slug',
						'terms' => explode(',',$idcate)
					),
				),
				'post_type' => 'service',
				'showposts' => $number1,
			);
		}else{
			$args = array(
				'post_type' => 'service',
				'posts_per_page' => $number1,
			);
		}
		
		$services = new WP_Query($args);
		if($services->have_posts()) : while($services->have_posts()) : $services->the_post(); $i++;	
		$color_service = get_post_meta(get_the_ID(),'_cmb_color_service', true);	
	?>

		<div class="box-service <?php if ($service_columns == 4) { echo 'box-four-columns'; }else { echo 'one-third'; } ?>" <?php if($service_style != 'light'){ echo 'style="background-color: '. $color_service .' ;"';} ?>>
            <div class="bg-color-fx padding-5 text-center <?php if($service_style != 'light'){ echo 'light-text';} ?>">
                <h3><?php the_title(); ?></h3>
                <div class="tiny-border margintop10 marginbottom10"></div>
                <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>" class="img-responsive margintop20 marginbottom20 wow fadeInRight" data-wow-delay="<?php echo $j = $i*0.3; ?>s" alt="<?php the_title(); ?>" />
                <p><?php echo get_the_excerpt(); ?></p>
                <?php if ($show_hide_btn != 'hide') { ?>
                	<a href="<?php the_permalink(); ?>" class="btn-arrow hover-light"><span class="line"></span><span class="url"><?php if($btntext != ''){echo esc_attr($btntext); }else{ _e('View Details', 'otvcp-i10n'); } ?></span></a>
            	<?php } ?>
            </div>
        </div>

    <?php endwhile; wp_reset_postdata(); endif; ?>    

<?php
    return ob_get_clean();
}

// Service Slider in Onepage Express
add_shortcode('ot_service_slider','ot_service_slider_func');
function ot_service_slider_func($atts, $content = null){
	extract(shortcode_atts(array(
		'title'	=>		'',
		'number'	=>		'',
		'idcate' => '',
		'btntext' => 'View Details',
		'show_hide_btn' => 'show'
	), $atts));
	$number1 = (!empty($number) ? esc_attr($number) : 4);	
	ob_start(); 
?>
	<div class="owl-custom-nav">
        <a class="btn-next"></a>
        <a class="btn-prev"></a>
    </div>
    <ul class="single-carousel-1 nav-s1">                                                 			 	  
		<?php
			if($idcate != ''){
				$args = array(
					'tax_query' => array(
						array(
							'taxonomy' => 'category_service',
							'field' => 'slug',
							'terms' => explode(',',$idcate)
						),
					),
					'post_type' => 'service',
					'showposts' => $number1,
				);
			}else{
				$args = array(
					'post_type' => 'service',
					'posts_per_page' => $number1,
				);
			}
			
			$services = new WP_Query($args);
			if($services->have_posts()) : while($services->have_posts()) : $services->the_post();	
		?>
			<li>
	            <div class="col-1">
	                <div class="inbox text-center">
	                    <h3><?php the_title(); ?></h3>
	                    <div class="tiny-border no-margin thin"></div>
	                    <div class="clearfix"></div>
	                    <?php the_post_thumbnail( 'full', array( 'class' => 'img-responsive margintop20 marginbottom20 wow fadeInUp' ) ); ?>	                    
	                </div>
	            </div>
	            <div class="col-2">
	                <div class="text-wrap">
		                <div class="service-inner-wrap">
		                	<p><?php echo get_the_excerpt(); ?></p>
		                    <?php if ($show_hide_btn != 'hide') { ?>
		                		<a href="<?php the_permalink(); ?>" class="btn-arrow hover-light"><span class="line"></span><span class="url"><?php if($btntext != ''){echo esc_attr($btntext); }else{ _e('View Details', 'otvcp-i10n'); } ?></span></a>
		            		<?php } ?>
		                </div>
	                </div>
	            </div>
	            <div class="clearfix"></div>
	        </li> 
	    <?php endwhile; wp_reset_postdata(); endif; ?>  
	</ul>  

<?php
    return ob_get_clean();
}

// Social Group use in preview 3
add_shortcode('socialgroup', 'socialgroup_func');
function socialgroup_func($atts, $content = null){
	extract(shortcode_atts(array(		
		'title'		=>	'',
		'icon1'		=>	'',
		'icon2'		=>	'',
		'icon3'		=>	'',
		'icon4'		=>	'',
		'icon5'		=>	'',
		'icon6'		=>	'',
		'url1'		=>	'',
		'url2'		=>	'',
		'url3'		=>	'',
		'url4'		=>	'',
		'url5'		=>	'',
		'url6'		=>	'',
	), $atts));

	$icon11 = (!empty($url1) ? '<a href="'.esc_url($url1).'" target="_blank"><i class="'.esc_attr($icon1).'"></i></a>' : '');
	$icon22 = (!empty($url2) ? '<a href="'.esc_url($url2).'" target="_blank"><i class="'.esc_attr($icon2).'"></i></a>' : '');
	$icon33 = (!empty($url3) ? '<a href="'.esc_url($url3).'" target="_blank"><i class="'.esc_attr($icon3).'"></i></a>' : '');
	$icon44 = (!empty($url4) ? '<a href="'.esc_url($url4).'" target="_blank"><i class="'.esc_attr($icon4).'"></i></a>' : '');
	$icon55 = (!empty($url5) ? '<a href="'.esc_url($url5).'" target="_blank"><i class="'.esc_attr($icon5).'"></i></a>' : '');
	$icon66 = (!empty($url6) ? '<a href="'.esc_url($url6).'" target="_blank"><i class="'.esc_attr($icon6).'"></i></a>' : '');

	ob_start(); ?>

	<?php if($title != ''){ ?><h5><?php echo esc_attr($title); ?></h5><?php } ?>
	<div class="social group-social">
        <?php echo htmlspecialchars_decode($icon11); ?>
        <?php echo htmlspecialchars_decode($icon22); ?>
        <?php echo htmlspecialchars_decode($icon33); ?>
        <?php echo htmlspecialchars_decode($icon44); ?>
        <?php echo htmlspecialchars_decode($icon55); ?>
        <?php echo htmlspecialchars_decode($icon66); ?>
    </div>	

<?php
    return ob_get_clean();
}

// Our Team (USE)
add_shortcode('team', 'team_func');
function team_func($atts, $content = null){
	extract(shortcode_atts(array(
		'photo'		=> 	'',
		'name'		=>	'',
		'job'		=>	'',
		'icon1'		=>	'',
		'icon2'		=>	'',
		'icon3'		=>	'',
		'icon4'		=>	'',
		'icon5'		=>	'',
		'icon6'		=>	'',
		'url1'		=>	'',
		'url2'		=>	'',
		'url3'		=>	'',
		'url4'		=>	'',
		'url5'		=>	'',
		'url6'		=>	'',
	), $atts));

	$img = wp_get_attachment_image_src($photo,'full');
	$img = $img[0];

	$icon11 = (!empty($url1) ? '<a href="'.esc_url($url1).'" target="_blank"><i class="'.esc_attr($icon1).' fa-lg"></i></a>' : '');
	$icon22 = (!empty($url2) ? '<a href="'.esc_url($url2).'" target="_blank"><i class="'.esc_attr($icon2).' fa-lg"></i></a>' : '');
	$icon33 = (!empty($url3) ? '<a href="'.esc_url($url3).'" target="_blank"><i class="'.esc_attr($icon3).' fa-lg"></i></a>' : '');
	$icon44 = (!empty($url4) ? '<a href="'.esc_url($url4).'" target="_blank"><i class="'.esc_attr($icon4).' fa-lg"></i></a>' : '');
	$icon55 = (!empty($url5) ? '<a href="'.esc_url($url5).'" target="_blank"><i class="'.esc_attr($icon5).' fa-lg"></i></a>' : '');
	$icon66 = (!empty($url6) ? '<a href="'.esc_url($url6).'" target="_blank"><i class="'.esc_attr($icon6).' fa-lg"></i></a>' : '');

	ob_start(); ?>

	<div class="team-profile">
        <img class="img-responsive" src="<?php echo esc_url($img); ?>" alt="">
        <div class="text">
            <h3><?php echo htmlspecialchars_decode($name); ?></h3>
            <?php if($job){ ?><h4 class="lead"><?php echo htmlspecialchars_decode($job); ?></h4><?php } ?>
            <?php if($content){ ?><div class="desc-team"><?php echo htmlspecialchars_decode($content); ?></div><?php } ?>
            <div class="team-social-icons">
                <?php echo htmlspecialchars_decode($icon11); ?>
                <?php echo htmlspecialchars_decode($icon22); ?>
                <?php echo htmlspecialchars_decode($icon33); ?>
                <?php echo htmlspecialchars_decode($icon44); ?>
                <?php echo htmlspecialchars_decode($icon55); ?>
                <?php echo htmlspecialchars_decode($icon66); ?>
            </div>
        </div>
    </div>

<?php
    return ob_get_clean();
}

// Our Team 2 (USE)
add_shortcode('team2', 'team2_func');
function team2_func($atts, $content = null){
	extract(shortcode_atts(array(
		'photo'		=> 	'',
		'name'		=>	'',
		'job'		=>	'',
		'icon1'		=>	'',
		'icon2'		=>	'',
		'icon3'		=>	'',
		'icon4'		=>	'',
		'icon5'		=>	'',
		'icon6'		=>	'',
		'url1'		=>	'',
		'url2'		=>	'',
		'url3'		=>	'',
		'url4'		=>	'',
		'url5'		=>	'',
		'url6'		=>	'',
	), $atts));

	$img = wp_get_attachment_image_src($photo,'full');
	$img = $img[0];

	$icon11 = (!empty($url1) ? '<a href="'.esc_url($url1).'" target="_blank"><i class="'.esc_attr($icon1).' fa-lg"></i></a>' : '');
	$icon22 = (!empty($url2) ? '<a href="'.esc_url($url2).'" target="_blank"><i class="'.esc_attr($icon2).' fa-lg"></i></a>' : '');
	$icon33 = (!empty($url3) ? '<a href="'.esc_url($url3).'" target="_blank"><i class="'.esc_attr($icon3).' fa-lg"></i></a>' : '');
	$icon44 = (!empty($url4) ? '<a href="'.esc_url($url4).'" target="_blank"><i class="'.esc_attr($icon4).' fa-lg"></i></a>' : '');
	$icon55 = (!empty($url5) ? '<a href="'.esc_url($url5).'" target="_blank"><i class="'.esc_attr($icon5).' fa-lg"></i></a>' : '');
	$icon66 = (!empty($url6) ? '<a href="'.esc_url($url6).'" target="_blank"><i class="'.esc_attr($icon6).' fa-lg"></i></a>' : '');

	ob_start(); ?>

	<div class="team-list text-center">
        <div class="pic">
            <span class="fx"></span>
            <img class="img-responsive" src="<?php echo esc_url($img); ?>" alt="<?php echo htmlspecialchars_decode($name); ?>">
        </div>
        <span class="name"><?php echo htmlspecialchars_decode($name); ?></span>
        <?php if($job){ ?><span class="position"><?php echo htmlspecialchars_decode($job); ?></span><?php } ?>
        <?php if($content){ ?><div class="desc-team"><?php echo htmlspecialchars_decode($content); ?></div><?php } ?>
        <div class="team-social-icons">
            <?php echo htmlspecialchars_decode($icon11); ?>
            <?php echo htmlspecialchars_decode($icon22); ?>
            <?php echo htmlspecialchars_decode($icon33); ?>
            <?php echo htmlspecialchars_decode($icon44); ?>
            <?php echo htmlspecialchars_decode($icon55); ?>
            <?php echo htmlspecialchars_decode($icon66); ?>
        </div>
    </div>

<?php
    return ob_get_clean();
}

// Our Team 3 use in preview 3
add_shortcode('team3', 'team3_func');
function team3_func($atts, $content = null){
	extract(shortcode_atts(array(
		'photo'		=> 	'',
		'name'		=>	'',
		'job'		=>	'',
		'icon1'		=>	'',
		'icon2'		=>	'',
		'icon3'		=>	'',
		'icon4'		=>	'',
		'icon5'		=>	'',
		'icon6'		=>	'',
		'url1'		=>	'',
		'url2'		=>	'',
		'url3'		=>	'',
		'url4'		=>	'',
		'url5'		=>	'',
		'url6'		=>	'',
		'css'		=>	'',
	), $atts));

	$img = wp_get_attachment_image_src($photo,'full');
	$img = $img[0];

	$icon11 = (!empty($url1) ? '<a href="'.esc_url($url1).'" target="_blank"><i class="'.esc_attr($icon1).'"></i></a>' : '');
	$icon22 = (!empty($url2) ? '<a href="'.esc_url($url2).'" target="_blank"><i class="'.esc_attr($icon2).'"></i></a>' : '');
	$icon33 = (!empty($url3) ? '<a href="'.esc_url($url3).'" target="_blank"><i class="'.esc_attr($icon3).'"></i></a>' : '');
	$icon44 = (!empty($url4) ? '<a href="'.esc_url($url4).'" target="_blank"><i class="'.esc_attr($icon4).'"></i></a>' : '');
	$icon55 = (!empty($url5) ? '<a href="'.esc_url($url5).'" target="_blank"><i class="'.esc_attr($icon5).'"></i></a>' : '');
	$icon66 = (!empty($url6) ? '<a href="'.esc_url($url6).'" target="_blank"><i class="'.esc_attr($icon6).'"></i></a>' : '');

	ob_start(); ?>

	<div class="<?php echo vc_shortcode_custom_css_class( $css ); ?>">
        <div class="row">
            <div class="col-md-6 pr0">
                <img class="img-responsive" src="<?php echo esc_url($img); ?>" alt="<?php echo htmlspecialchars_decode($name); ?>">
            </div>
            <div class="col-md-6">
                <div class="p20 pl10 pt30">
                    <div class="id-color font2"><i><?php echo htmlspecialchars_decode($name); ?></i></div>
                    <?php if($job){ ?><div class="font2 mb10 text-white"><i><?php echo htmlspecialchars_decode($job); ?></i></div><?php } ?>
                    <?php echo htmlspecialchars_decode($content); ?>
				
					<!-- social icons -->
                    <div class="social hspace10 mt10">
                        <?php echo htmlspecialchars_decode($icon11); ?>
			            <?php echo htmlspecialchars_decode($icon22); ?>
			            <?php echo htmlspecialchars_decode($icon33); ?>
			            <?php echo htmlspecialchars_decode($icon44); ?>
			            <?php echo htmlspecialchars_decode($icon55); ?>
			            <?php echo htmlspecialchars_decode($icon66); ?>
                    </div>
                    <!-- social icons close -->
                </div>
            </div>
        </div>
    </div>

<?php
    return ob_get_clean();
}

// Our Facts
add_shortcode('ourfacts', 'ourfacts_func');
function ourfacts_func($atts, $content = null){
	extract(shortcode_atts(array(
		'title'		=> 	'',
		'number'    => 	'',
	), $atts));
	ob_start(); ?>

	<div class="counter">
        <div class="num">
            <?php echo esc_attr($number); ?>
			<div class="tiny-border"></div>
        </div>
        <div class="text">
            <?php echo htmlspecialchars_decode($title); ?>
        </div>
    </div>

<?php
    return ob_get_clean();
}		

// Other Services
add_shortcode('other_service', 'other_service_func');
function other_service_func($atts, $content = null){
	extract(shortcode_atts(array(
		'title'		=> 	'',
		'photo'    => 	'',
		'delay'		=> '',
		'service_columns' => '',
		'animate'  => ''	
	), $atts));
	$delay1 = (!empty($delay) ? $delay : 0.2);
	$img = wp_get_attachment_image_src($photo,'full');
	$img = $img[0];
	$col_animate = '';
	if($animate == 'none'){
		$col_animate = '';
	}elseif ($animate == 'fadeinup') {
		$col_animate = 'wow fadeInUp';
	}elseif ($animate == 'fadeindown') {
		$col_animate = 'wow fadeInDown';
	}elseif ($animate == 'fadein') {
		$col_animate = 'wow fadeIn';
	}elseif ($animate == 'fadeinleft') {
		$col_animate = 'wow fadeInLeft';
	}else{
		$col_animate = 'wow fadeInRight';
	}
	ob_start(); ?>

	<div class="<?php if ($service_columns == 2) {echo 'box-two-columns'; }elseif ($service_columns == 3) { echo 'box-one-third'; }elseif ($service_columns == 4) { echo 'box-four-columns'; }else{ echo 'box-five-columns'; } ?> <?php echo esc_attr($col_animate); ?>" data-wow-delay="<?php echo esc_attr($delay1); ?>s" style="background: url(<?php echo esc_url($img); ?>);background-size:cover;">
        <div class="bg-color-fx light-text padding-5 text-center">
            <h3><?php echo htmlspecialchars_decode($title); ?></h3>
            <p><?php echo htmlspecialchars_decode($content); ?></p>
            <div class="tiny-border"></div>
        </div>
    </div>

<?php
    return ob_get_clean();
}	

// Contact Info
add_shortcode('info_contact', 'info_contact_func');
function info_contact_func($atts, $content = null){
	extract(shortcode_atts(array(
		'title'		=> 	'',		
		'linkbox'		=>  '',
		'css'   =>  '',
	), $atts));	
	$url = vc_build_link( $linkbox );
	ob_start(); ?>	

	<div class="contact_info <?php echo vc_shortcode_custom_css_class( $css ); ?>">
		<h3><?php echo htmlspecialchars_decode($title); ?></h3>
	    <?php echo htmlspecialchars_decode($content); ?>
	    <div class="divider-single"></div>
	    <?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {
			echo '<a href="' . esc_attr( $url['url'] ) . '" class="btn-border popup-gmaps" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) . '</a>';
		} ?> 
	</div>	      

<?php
    return ob_get_clean();
}

// Contact Info 2
add_shortcode('info_contact2', 'info_contact2_func');
function info_contact2_func($atts, $content = null){
	extract(shortcode_atts(array(
		'title'		=> 	'',		
		'icon_fontawesome'		=>  '',
		'css'   =>  '',
	), $atts));	
	$url = vc_build_link( $linkbox );
	ob_start(); ?>	

	<div class="info-box <?php echo vc_shortcode_custom_css_class( $css ); ?>">
        <i class="<?php echo esc_attr($icon_fontawesome); ?>"></i>
        <div class="info-box_text">
            <?php if($title != ''){ ?><div class="info-box_title"><?php echo htmlspecialchars_decode($title); ?></div><?php } ?>
            <?php if($content != ''){ ?><div class="info-box_subtite"><?php echo htmlspecialchars_decode($content); ?></div><?php } ?>
        </div>
    </div>      

<?php
    return ob_get_clean();
}

// Latest Blog
add_shortcode('latestblog','latestblog_func');
function latestblog_func($atts, $content = null){
	extract(shortcode_atts(array(
		'number'	=>		'',
		'excerpt'   =>		'',
		'linkbox'   =>		'',
		'columns' =>		'2col',
	), $atts));
	$url = vc_build_link( $linkbox );
	$number1 = (!empty($number) ? $number : 6);
	$excerpt1 = (!empty($excerpt) ? $excerpt : 19);

	ob_start(); ?>	
	<div class="row">
		 <div id="newslist" class="news-list">
		 	<?php 
			    $args = array(   
			        'post_type' => 'post',   
			        'posts_per_page' => $number1,
			    );  
			    $wp_query = new WP_Query($args);
			    while($wp_query->have_posts()) : $wp_query->the_post(); 
		    ?>
	        <div class="<?php if($columns == '2col'){echo 'col-md-6';}elseif ($columns == '3col') {echo 'col-md-4';}else{echo 'col-md-3';} ?> news-item item">
	        	<?php 
	        		if ( has_post_thumbnail() ) {
	        			the_post_thumbnail( 'homepage-thumb', array( 'class'	=> "img-responsive") );
	        		}	
				?>
	            <div class="desc">
	                <a href="<?php the_permalink(); ?>"><h3><?php the_title(); ?></h3></a>
	                <div class="post-details"><?php gocargo_entry_meta(); ?></div>
	                <?php echo gocargo_excerpt($excerpt1); ?>
					<br>
	            </div>
	        </div>
	        <?php endwhile; wp_reset_postdata(); ?>
		</div>
	</div>
	<?php if ( strlen( $linkbox ) > 0 && strlen( $url['url'] ) > 0 ) {
			echo '<div class="btn_blog text-center"><a class="btn-custom btn-big" href="' . esc_attr( $url['url'] ) . '" title="' . esc_attr( $url['title'] ) . '" target="' . ( strlen( $url['target'] ) > 0 ? esc_attr( $url['target'] ) : '_self' ) . '">' . esc_attr( $url['title'] ) . '</a></div>';
    } ?>
<?php
    return ob_get_clean();
}

// Latest Blog 2
add_shortcode('latestblog2','latestblog2_func');
function latestblog2_func($atts, $content = null){
	extract(shortcode_atts(array(
		'number'	=>		'',
		'excerpt'   =>		'',
		'columns' =>		'2col',
	), $atts));	
	$number1 = (!empty($number) ? $number : 3);
	$excerpt1 = (!empty($excerpt) ? $excerpt : 19);

	ob_start(); ?>	
	<div class="row">
	 	<?php 
		    $args = array(   
		        'post_type' => 'post',   
		        'posts_per_page' => $number1,
		    );  
		    $wp_query = new WP_Query($args);
		    while($wp_query->have_posts()) : $wp_query->the_post(); 
		    $format = get_post_format();
	    ?>	
	    <div class="<?php if($columns == '2col'){echo 'col-md-6';}elseif ($columns == '3col') {echo 'col-md-4';}else{echo 'col-md-3';} ?> news-item style-2">
	    	<figure class="pic-hover">

	            <span class="center-xy">
	            	<?php if($format=='video'){ $link_video = get_post_meta(get_the_ID(),'_cmb_link_video', true); ?>
	                	<a class="popup-youtube" href="<?php echo esc_url($link_video); ?>"><i class="fa fa-play btn-action btn-play"></i></a>
	            	<?php } ?>
	            </span>

	            <span class="bg-overlay"></span>
	            <?php 
		    		if ( has_post_thumbnail() ) {
		    			the_post_thumbnail( 'full', array( 'class'	=> "img-responsive") );
		    		}	
				?>
	        </figure>

	        <div class="inner">
	            <div class="date">
	                <span class="day"><?php the_time('d') ?></span>
	                <span class="month"><?php the_time('M') ?></span>
	            </div>

	            <div class="desc">
	                <a href="<?php the_permalink(); ?>"><h4><?php the_title(); ?></h4></a>
	                <?php echo gocargo_excerpt($excerpt1); ?>
					<br>
	            </div>
	        </div>

	    </div>
	    <?php endwhile; wp_reset_postdata(); ?>
    </div>
<?php
    return ob_get_clean();
}

// Latest Blog 3
add_shortcode('latestblog3','latestblog3_func');
function latestblog3_func($atts, $content = null){
	extract(shortcode_atts(array(
		'number'	=>		'',
		'excerpt'   =>		'',
		'columns'   =>		'2col',
	), $atts));

	$number1 = (!empty($number) ? $number : 6);
	$excerpt1 = (!empty($excerpt) ? $excerpt : 19);

	ob_start(); ?>	

	<div class="news-list">
		<?php 
		    $args = array(   
		        'post_type' => 'post',   
		        'posts_per_page' => $number1,
		    );  
		    $wp_query = new WP_Query($args);
		    while($wp_query->have_posts()) : $wp_query->the_post(); 
	    ?>
	        <div class="<?php if($columns == '2col'){echo 'col-md-6';}elseif ($columns == '3col') {echo 'col-md-4';}else{echo 'col-md-3';} ?> news-item style-3 item">
	            <div class="inner">
	                <div class="date">
	                    <span class="day"><?php the_time('d') ?></span>
                        <span class="month"><?php the_time('M') ?></span>
	                </div>
	                <div class="desc">
	                    <a href="<?php the_permalink(); ?>">
	                        <h4><?php the_title(); ?></h4>
	                    </a>
	                    <?php echo gocargo_excerpt($excerpt1); ?>
						<br>
	                </div>
	            </div>
	        </div>
        <?php endwhile; wp_reset_postdata(); ?>
    </div>

<?php
    return ob_get_clean();
}

// Close Map use in preview 3
add_shortcode('closemap','closemap_func');
function closemap_func($atts, $content = null){
	extract(shortcode_atts(array(			
		'title'		=>	'View on Map',	
	), $atts));
	ob_start(); ?>

	<span class="btn-arrow btn-open-map"><span class="line"></span><span class="url"><?php echo esc_attr($title); ?></span></span>
	
<?php
    return ob_get_clean();
}

// Google Map (Use)
add_shortcode('ggmap','ggmap_func');
function ggmap_func($atts, $content = null){
    extract( shortcode_atts( array(
	  'height'		=> '',	
      'lat'   		=> '',
      'long'	  	=> '',
      'zoom'		=> '',
	  'icon'		=> '',
	  'style'		=> 'dark',
	  'gmap_custom_style' => '',
   ), $atts ) );
      
	$id = uniqid( 'map-' );
	$gmap_custom_style1 = rawurldecode( base64_decode( strip_tags( $gmap_custom_style ) ) );
	$icon1 = wp_get_attachment_image_src($icon,'full');
	$icon1 = $icon1[0];
   		
    ob_start(); ?>
    	 
    <div class="gocargo_gmap" id="<?php echo esc_attr($id); ?>" style="<?php if($height != ''){ echo 'height: '.$height.'px;'; } ?>"></div>

    <script type="text/javascript">	
		(function($) {
	    "use strict"
		    $(document).ready(function(){
		    	// When the window has finished loading create our google map below
		        google.maps.event.addDomListener(window, 'load', init);

		        function init() {
					'use strict'; // use strict mode
					
		            // Basic options for a simple Google Map
		            // For more options see: https://developers.google.com/maps/documentation/javascript/reference#MapOptions
		            var myLatlng = new google.maps.LatLng(<?php echo esc_js( $lat );?>, <?php echo esc_js( $long );?>);

		            var mapOptions = {
		                // How zoomed in you want the map to start at (always required)
		                zoom: <?php echo esc_js( $zoom );?>,
		                disableDefaultUI: false,
						scrollwheel: false,

		                // The latitude and longitude to center the map (always required)

		                center: myLatlng, // New York

		                // How you would like to style the map. 
		                // This is where you would paste any style found on Snazzy Maps.
		                styles: 
		                	<?php if($style == 'light'){ ?>
								[{
							        "featureType": "administrative",
							        "elementType": "geometry",
							        "stylers": [
							            {
							                "saturation": "2"
							            },
							            {
							                "visibility": "simplified"
							            }
							        ]
							    },
							    {
							        "featureType": "administrative",
							        "elementType": "labels",
							        "stylers": [
							            {
							                "saturation": "-28"
							            },
							            {
							                "lightness": "-10"
							            },
							            {
							                "visibility": "on"
							            }
							        ]
							    },
							    {
							        "featureType": "administrative",
							        "elementType": "labels.text.fill",
							        "stylers": [
							            {
							                "color": "#444444"
							            }
							        ]
							    },
							    {
							        "featureType": "landscape",
							        "elementType": "all",
							        "stylers": [
							            {
							                "color": "#f2f2f2"
							            }
							        ]
							    },
							    {
							        "featureType": "landscape",
							        "elementType": "geometry.fill",
							        "stylers": [
							            {
							                "saturation": "-1"
							            },
							            {
							                "lightness": "-12"
							            }
							        ]
							    },
							    {
							        "featureType": "landscape.natural",
							        "elementType": "labels.text",
							        "stylers": [
							            {
							                "lightness": "-31"
							            }
							        ]
							    },
							    {
							        "featureType": "landscape.natural",
							        "elementType": "labels.text.fill",
							        "stylers": [
							            {
							                "lightness": "-74"
							            }
							        ]
							    },
							    {
							        "featureType": "landscape.natural",
							        "elementType": "labels.text.stroke",
							        "stylers": [
							            {
							                "lightness": "65"
							            }
							        ]
							    },
							    {
							        "featureType": "landscape.natural.landcover",
							        "elementType": "geometry",
							        "stylers": [
							            {
							                "lightness": "-15"
							            }
							        ]
							    },
							    {
							        "featureType": "landscape.natural.landcover",
							        "elementType": "geometry.fill",
							        "stylers": [
							            {
							                "lightness": "0"
							            }
							        ]
							    },
							    {
							        "featureType": "poi",
							        "elementType": "all",
							        "stylers": [
							            {
							                "visibility": "off"
							            }
							        ]
							    },
							    {
							        "featureType": "road",
							        "elementType": "all",
							        "stylers": [
							            {
							                "saturation": -100
							            },
							            {
							                "lightness": 45
							            }
							        ]
							    },
							    {
							        "featureType": "road",
							        "elementType": "geometry",
							        "stylers": [
							            {
							                "visibility": "on"
							            },
							            {
							                "saturation": "0"
							            },
							            {
							                "lightness": "-9"
							            }
							        ]
							    },
							    {
							        "featureType": "road",
							        "elementType": "geometry.stroke",
							        "stylers": [
							            {
							                "lightness": "-14"
							            }
							        ]
							    },
							    {
							        "featureType": "road",
							        "elementType": "labels",
							        "stylers": [
							            {
							                "lightness": "-35"
							            },
							            {
							                "gamma": "1"
							            },
							            {
							                "weight": "1.39"
							            }
							        ]
							    },
							    {
							        "featureType": "road",
							        "elementType": "labels.text.fill",
							        "stylers": [
							            {
							                "lightness": "-19"
							            }
							        ]
							    },
							    {
							        "featureType": "road",
							        "elementType": "labels.text.stroke",
							        "stylers": [
							            {
							                "lightness": "46"
							            }
							        ]
							    },
							    {
							        "featureType": "road.highway",
							        "elementType": "all",
							        "stylers": [
							            {
							                "visibility": "simplified"
							            }
							        ]
							    },
							    {
							        "featureType": "road.highway",
							        "elementType": "labels.icon",
							        "stylers": [
							            {
							                "lightness": "-13"
							            },
							            {
							                "weight": "1.23"
							            },
							            {
							                "invert_lightness": true
							            },
							            {
							                "visibility": "simplified"
							            },
							            {
							                "hue": "#ff0000"
							            }
							        ]
							    },
							    {
							        "featureType": "road.arterial",
							        "elementType": "labels.icon",
							        "stylers": [
							            {
							                "visibility": "off"
							            }
							        ]
							    },
							    {
							        "featureType": "transit",
							        "elementType": "all",
							        "stylers": [
							            {
							                "visibility": "off"
							            }
							        ]
							    },
							    {
							        "featureType": "water",
							        "elementType": "all",
							        "stylers": [
							            {
							                "color": "#adadad"
							            },
							            {
							                "visibility": "on"
							            }
							        ]
							    }]

							<?php }elseif($style=='dark'){ ?>
								[{
									"stylers": [
										{
											"hue": "#ff1a00"
										},
										{
											"invert_lightness": true
										},
										{
											"saturation": -100
										},
										{
											"lightness": 33
										},
										{
											"gamma": 0.5
										}
									]
								},
								{
									"featureType": "water",
									"elementType": "geometry",
									"stylers": [
										{
											"color": "#2D333C"
										}
									]
								}]
							<?php }else{ 
								echo $gmap_custom_style1;
							} ?>						
		            };

		            // Get the HTML DOM element that will contain your map 
		            // We are using a div with id="map" seen below in the <body>
		            var mapElement = document.getElementById('<?php echo esc_attr($id); ?>');

		            // Create the Google Map using out element and options defined above
		            var map = new google.maps.Map(mapElement, mapOptions);

		            var marker = new google.maps.Marker({
		                position: myLatlng,
		                map: map,
						icon: '<?php echo esc_js( $icon1 );?>',
		                title: 'Your item position'
		            });
		        }		        
	        });
	    })(jQuery);   	
   	</script>
<?php
    return ob_get_clean();
}

//OT Accordion List
if(function_exists('vc_map')){
	//Register "container" content element. It will hold all your inner (child) content elements
	vc_map( array(
		"name"                    => __("OT Accordion", "otvcp-i10n"),
		"base"                    => "accordion_list",
		"as_parent"               => array('only' => 'single_accordion_list'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
		"content_element"         => true,
		"icon"                    => "icon-st",
		"show_settings_on_create" => false,
		"params"                  => array(         
			// add params same as with any other content element
			array(
				"type"        => "textfield",
				"heading"     => __("Extra class name", "otvcp-i10n"),
				"param_name"  => "el_class",
				"description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "otvcp-i10n")
			)
		),
		"js_view" => 'VcColumnView'
	) );
	vc_map( array(
		"name" => __("Single Accordion", "otvcp-i10n"),
		"base" => "single_accordion_list",
		"content_element" => true,
		"icon" => "icon-st",
		"as_child" => array('only' => 'accordion_list'), // Use only|except attributes to limit parent (separate multiple values with comma)
		"params" => array(
			// add params same as with any other content element
			array(
				"type" => "textfield",
				"heading" => __("Title", "otvcp-i10n"),
				"param_name" => "title",
			),
			array(
				"type" => "textarea",
				"heading" => __("Description", "otvcp-i10n"),
				"param_name" => "desc",
			),        
		)
	) );
}

//Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_accordion_list extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_single_accordion_list extends WPBakeryShortCode {
    }
}


// Accordion List
$GLOBALS['plans'] = array();
add_shortcode('accordion_list', 'accordion_list_func');
 function accordion_list_func( $atts, $content ) {
  $atts = shortcode_atts(array(
   'css_class' => ''
  ), $atts );
  ob_start();
?>

<ul class="accordion style-2">
	<?php 
	  $GLOBALS['plans'] = array();
	  do_shortcode( $content );
	  if ( empty( $GLOBALS['plans'] ) ) {
	   return '';
	  }
	  $content_nav = array();
	  $total      = count( $GLOBALS['plans'] );
	  if ( ! $total ) {
	   return '';
	  }	 
	  foreach( $GLOBALS['plans'] as $index => $plan ) {
	   $content_nav[] = sprintf(
	   '<li>
	        <a class="NoneActive">%s</a>
	        <div class="content">%s</div>
	    </li>',			    
	   esc_attr( $plan['title'] ),
	   esc_attr( $plan['desc'] )   
	  );
	}
	  echo implode( '', $content_nav);
	?>    
</ul>
<?php 
	return ob_get_clean();
}

//Single Plan
add_shortcode('single_accordion_list', 'single_accordion_list_func');
function single_accordion_list_func( $atts, $content ) {
  $atts = shortcode_atts(array(
   'title'      => '',
   'desc'       => '',
  ), $atts );

  $GLOBALS['plans'][] = array(
   'title'      => $atts['title'],
   'desc'       => $atts['desc'],
  );

  return '';
}

//OT FAQs
add_shortcode('ot_faqs', 'ot_faqs_func');
function ot_faqs_func($atts, $content = null){
	extract(shortcode_atts(array(
		'title'		=> 	'',	
	), $atts));	
	ob_start(); ?>	

	<div class="faq">
	    <span class="btn-expand"></span>
	    <div class="inner">
	        <i class="icon-search"></i>
	        <h4><?php echo htmlspecialchars_decode($title); ?></h4>
	    </div>
	    <div class="hide-content">
	        <?php echo htmlspecialchars_decode($content); ?>
	    </div>
	</div>      

<?php
    return ob_get_clean();
}


// OT BOARD OF DIRECTOR
add_shortcode('ot_board_of_director', 'ot_board_of_director_func');
function ot_board_of_director_func($atts, $content = null){
   extract(shortcode_atts(array(
      'title'   => '',
      'titles' => '',
      'extraclass' => ''
   ), $atts));
   $titles = (array) vc_param_group_parse_atts( $titles );
   ob_start(); 
?>

<div class="carousel-1 <?php echo esc_attr($extraclass); ?>">
	<?php 
	    foreach ( $titles as $data ) {
			$data['title'] = isset( $data['title'] ) ? $data['title'] : '';
			$data['desc'] = isset( $data['desc'] ) ? $data['desc'] : '';
			$data['avatar'] = isset( $data['avatar'] ) ? $data['avatar'] : '';
			$img = wp_get_attachment_image_src($data['avatar'],'full');
	        $img = $img[0];
	?>			
        <div class="item">
            <div class="text"><?php echo $data['desc']; ?></div>
            <div class="name id-color"><?php echo $data['title']; ?></div>
            <img src="<?php echo esc_url($img); ?>" alt="<?php echo $data['title']; ?>">
        </div>	        
	<?php } ?>
</div>   

<?php 
   return ob_get_clean();
}


// OT Contact Info 3 use in GoCargo Express version
add_shortcode('contact_info3', 'contact_info3_func');
function contact_info3_func($atts, $content = null){
   extract(shortcode_atts(array(
      'title'   => '',
      'socials' => '',
      'address' => '',
      'phone' => '',
      'email' => '',
      'extraclass' => ''
   ), $atts));
   $socials = (array) vc_param_group_parse_atts( $socials );
   ob_start(); 
?>
	
	<div class="address-with-icon">
        <div>
            <i class="fa fa-map-marker"></i>
            <div><?php echo htmlspecialchars_decode($address); ?></div>
        </div>
        <div>
            <i class="fa fa-phone"></i>
            <div>
                <?php echo htmlspecialchars_decode($phone); ?>
            </div>
        </div>
        <div>
            <i class="fa fa-envelope"></i>
            <div><?php echo htmlspecialchars_decode($email); ?></div>
        </div>
        <div>
            <i class="fa fa-group"></i>
            <div>
                <!-- social icons -->
                <div class="social">
                	<?php 
					    foreach ( $socials as $data ) {
							$data['link_icon'] = isset( $data['link_icon'] ) ? $data['link_icon'] : '';
							$data['link_url'] = isset( $data['link_url'] ) ? $data['link_url'] : '';							
					?>			
						<a href="<?php echo $data['link_url']; ?>"><i class="fa fa-<?php echo $data['link_icon']; ?>"></i></a>       
					<?php } ?>
                </div>
                <!-- social icons close -->
            </div>
        </div>
    </div>

<?php 
   return ob_get_clean();
}

// OT Footer Box - Use in GoCargo Express
add_shortcode('ot_footer_box', 'ot_footer_box_func');
function ot_footer_box_func($atts, $content = null){
	extract(shortcode_atts(array(
		'title'			=> 	'',	
		'icon' 			=> 	'',	
		'extra_class'   => 	'',	
		'css'			=> 	'',			
	), $atts));	
	$content = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content
	ob_start(); ?>	

	<div class="footer-col <?php echo vc_shortcode_custom_css_class( $css ) . ' ' . esc_attr($extra_class); ?>">
        <div class="title-with-icon-box">
            <i class="fa fa-<?php echo esc_attr($icon); ?>"></i>
            <h4><?php echo esc_attr($title); ?></h4>
            <div class="clearfix"></div>
        </div>
        <?php echo $content; ?>
    </div>     

<?php
    return ob_get_clean();
}

add_shortcode('branch_info_tab', 'branch_info_tab_func');
function branch_info_tab_func($atts, $content = null){
	extract(shortcode_atts(array(
		'title'			=> 	'',	
		'height' 		=> 	'',	
		'zoommap'   	=> 	'',	
		'iconmap'		=> 	'',	
		'columns'   	=>	'2col',
		'branchs'   	=>  '',
		'style'			=> 'default',
		'gmap_custom_style' => '',
		'socials' => '',
	), $atts));	
	$branchs = (array) vc_param_group_parse_atts( $branchs );
	$iconmap = wp_get_attachment_image_src($iconmap,'full');
	$iconmap = $iconmap[0];
	$height1 = (!empty($height) ? $height : 300);
	$zoommap1 = (!empty($zoommap) ? $zoommap : 12);
	$gmap_custom_style1 = rawurldecode( base64_decode( strip_tags( $gmap_custom_style ) ) );
	ob_start(); ?>	

	<div class="exo_tab tab_map">
        <div class="exo_nav row">
        	<?php 
        		$i=1;
			    foreach ( $branchs as $data ) {
					$data['title'] = isset( $data['title'] ) ? $data['title'] : '';
					$data['subtitle'] = isset( $data['subtitle'] ) ? $data['subtitle'] : '';						
			?>							 
				<div class="nav-item <?php if($columns == '2col'){echo 'col-md-6';}elseif ($columns == '3col') {echo 'col-md-4';}elseif ($columns == '6col') {echo 'col-md-2';}else{echo 'col-md-3';} ?>">
	                <div <?php if($i == 1){ ?>class="active"<?php } ?> >
	                    <h5><?php echo $data['title']; ?></h5>
	                    <h4><?php echo $data['subtitle']; ?></h4>
	                </div>
	            </div>      
			<?php $i++; } ?>
        </div>

        <div class="exo_tab_content">
        	<?php 
        		$j=1;
			    foreach ( $branchs as $data ) {
			    	$data['subtitle'] = isset( $data['subtitle'] ) ? $data['subtitle'] : '';
					$data['address'] = isset( $data['address'] ) ? $data['address'] : '';
					$data['phone'] = isset( $data['phone'] ) ? $data['phone'] : '';
					$data['email'] = isset( $data['email'] ) ? $data['email'] : '';
					$data['lat'] = isset( $data['lat'] ) ? $data['lat'] : '';
					$data['long	'] = isset( $data['long'] ) ? $data['long'] : '';						
			?>
	            <div id="tab<?php echo esc_attr($j); ?>">
	                <div class="map-wrapper">
	                    <div id="branch-map-<?php echo esc_attr($j); ?>" style="width: 100%;height: <?php echo esc_attr($height1); ?>px;"></div>
	                    <script type="text/javascript">
		                    (function($) {
						    "use strict"
							    $(document).ready(function(){
			                    	// When the window has finished loading create our google map below
				                    google.maps.event.addDomListener(window, 'load', init);

				                    function init() {
										'use strict'; // use strict mode
										
				                        // Basic options for a simple Google Map
				                        // For more options see: https://developers.google.com/maps/documentation/javascript/reference#MapOptions
				                        var myLatlng = new google.maps.LatLng(<?php echo esc_js($data['lat']); ?>,<?php echo esc_js($data['long']); ?>);

				                        var mapOptions = {
				                            // How zoomed in you want the map to start at (always required)
				                            zoom: <?php echo esc_js($zoommap1); ?>,
				                            disableDefaultUI: false,
											scrollwheel: false,

				                            // The latitude and longitude to center the map (always required)

				                            center: myLatlng, // New York

				                            // How you would like to style the map. 
				                            // This is where you would paste any style found on Snazzy Maps.
				                            <?php if($style == 'customize_gmap'){ ?>
				                            	styles: <?php echo $gmap_custom_style1; ?>
				                            <?php }else{ ?>	
				                            	styles: [{"stylers":[{"hue":"#05315c"},{"visibility":"on"},{"invert_lightness":true},{"saturation":40},{"lightness":10}]}]
				                            <?php } ?>	
				                        };

				                        // Get the HTML DOM element that will contain your map 
				                        // We are using a div with id="map" seen below in the <body>
				                        var mapElement = document.getElementById('branch-map-<?php echo esc_js($j); ?>');

				                        // Create the Google Map using out element and options defined above
				                        var map = new google.maps.Map(mapElement, mapOptions);

				                        var marker = new google.maps.Marker({
				                            position: myLatlng,
				                            map: map,
											icon: '<?php echo esc_js( $iconmap );?>',
				                            title: '<?php echo esc_js($data['subtitle']); ?>'
				                        });

				                    }
				                });
			    			})(jQuery);     
	                    </script>
	                </div>
	                <div class="text-wrapper">
	                    <div class="padding30">
	                        <div class="address-with-icon">
	                        	<?php if($data['address'] != ''){ ?>
		                            <div>
		                                <i class="fa fa-map-marker"></i>
		                                <div><?php echo $data['address']; ?></div>
		                            </div>
	                            <?php } ?>
	                            <?php if($data['phone'] != ''){ ?>
		                            <div>
		                                <i class="fa fa-phone"></i>
		                                <div>
		                                    <?php echo $data['phone']; ?>
		                                </div>
		                            </div>
	                            <?php } ?>
								<?php if($data['email'] != ''){ ?>
		                            <div>
		                                <i class="fa fa-envelope"></i>
		                                <div><?php echo $data['email']; ?></div>
		                            </div>
	                            <?php } ?>
	                            <?php if($socials != ''){ ?>
		                            <div>
		                                <i class="fa fa-group"></i>
		                                <div>
		                                    <!-- social icons -->
		                                    <div class="social">
		                                        <?php echo $socials; ?>
		                                    </div>
		                                    <!-- social icons close -->
		                                </div>
		                            </div>
	                            <?php } ?>
	                        </div>
	                    </div>
	                </div>
	                <div class="clearfix"></div>
	            </div>
            <?php $j++; } ?>
        </div>
    </div>    

<?php
    return ob_get_clean();
}