<?php
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
/*------------------------------GoCargo Metabox------------------------------*/

function gocargo_shipment_register_meta_boxes( $meta_boxes ) {
    $meta_boxes[] = array(
        'id'         => 'gocargo_shipment_history',
        'title'      => 'GoCargo Shipment History',
        'pages'      => array( 'gocargo_shipment' ), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'fields' => array(
            array(
                // Gropu id
                'id'     => 'standard',
                // Gropu field
                'type'   => 'group',
                // Clone whole group?
                'clone'  => true,
                // Drag and drop clones to reorder them?
                'sort_clone' => true,
                // Sub-fields
                'fields' => array(
                    array(
                        'name' => esc_html__( 'Time', 'gocargo-shipment' ),
                        'id'   => 'history_time',
                        'type' => 'time',
                        'format ' => 'hh:mm',
                    ),
                    array(
                        'name' => esc_html__( 'Date', 'gocargo-shipment' ),
                        'id'   => 'history_date',
                        'type' => 'date',
                        'format' => 'M dd, yy',
                    ),
                    array(
                        'name'    => esc_html__( 'Status', 'gocargo-shipment' ),
                        'id'      => 'history_status',
                        'type'    => 'select_advanced',
                        'options' => array(
                            'info_received'  => esc_html__( 'Info Received', 'gocargo-shipment' ),
                            'in_transit'  => esc_html__( 'In Transit', 'gocargo-shipment' ),
                            'out_for_delivery'  => esc_html__( 'Out for Delivery', 'gocargo-shipment' ),
                            'delivered'  => esc_html__( 'Delivered', 'gocargo-shipment' ),
                            'failed_attempt'  => esc_html__( 'Failed Attempt', 'gocargo-shipment' ),
                            'exception'  => esc_html__( 'Exception', 'gocargo-shipment' ),
                            'expired'  => esc_html__( 'Expired', 'gocargo-shipment' ),
                            'pending'  => esc_html__( 'Pending', 'gocargo-shipment' ),
                            'trucking'  => esc_html__( 'Trucking', 'gocargo-shipment' ),
                            'air_freight' => esc_html__( 'Air Freight', 'gocargo-shipment' ),
                            'ocean_freight' => esc_html__( 'Ocean Freight', 'gocargo-shipment' ),
                        ),
                    ),
                    array(
                        'name' => esc_html__( 'Remarks', 'gocargo-shipment' ),
                        'id'   => 'history_remarks',
                        'type' => 'textarea',
                    ),
                    // Map requires at least one address field (with type = text)
                    array(
                        'id'   => 'address',
                        'name' => esc_html__( 'Address', 'gocargo-shipment' ),
                        'type' => 'text',
                        'std'  => '',
                    ),
                    array(
                        'id'   => 'location',
                        'name' => esc_html__( 'Link gmap', 'gocargo-shipment' ),
                        'type' => 'textarea',
                    ),
                ),
            ),
        ),
    );

    // 4th Meta Box: No wrapper
    $meta_boxes[] = array(
        'id'         => 'gocargo_custom_fields',
        'title'      => 'GoCargo Custom Fields',
        'pages'      => array( 'gocargo_shipment' ), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'tabs'        => array(            
            'shipper'  => array(
                'label' => esc_html__( 'Shipper Information', 'gocargo-shipment' ),
                'icon'  => 'dashicons-admin-users',
            ),
            'receiver'  => array(
                'label' => esc_html__( 'Receiver Information', 'gocargo-shipment' ),
                'icon'  => 'dashicons-admin-users',
            ),
            'shipment' => array(
                'label' => esc_html__( 'Shipment Information', 'gocargo-shipment' ),
                'icon'  => 'dashicons-text', 
            ),
        ),
        'tab_style'   => 'default',
        'fields'      => array(
            // Shipper information
            array(
                'name' => esc_html__( 'Shipper Name', 'gocargo-shipment' ),
                'id'   => 'shipper_name',
                'type' => 'text',
                'tab'  => 'shipper',
            ),
            array(
                'name' => esc_html__( 'Phone', 'gocargo-shipment' ),
                'id'   => 'shipper_phone',
                'type' => 'text',
                'tab'  => 'shipper',
            ),
            array(
                'name' => esc_html__( 'Address', 'gocargo-shipment' ),
                'id'   => 'shipper_address',
                'type' => 'textarea',
                'tab'  => 'shipper',
            ),
            array(
                'name' => esc_html__( 'Email', 'gocargo-shipment' ),
                'id'   => 'shipper_email',
                'type' => 'text',
                'tab'  => 'shipper',
            ),

            // Receiver information
            array(
                'name' => esc_html__( 'Receiver Name', 'gocargo-shipment' ),
                'id'   => 'receiver_name',
                'type' => 'text',
                'tab'  => 'receiver',
            ),
            array(
                'name' => esc_html__( 'Phone', 'gocargo-shipment' ),
                'id'   => 'receiver_phone',
                'type' => 'text',
                'tab'  => 'receiver',
            ),
            array(
                'name' => esc_html__( 'Address', 'gocargo-shipment' ),
                'id'   => 'receiver_address',
                'type' => 'textarea',
                'tab'  => 'receiver',
            ),
            array(
                'name' => esc_html__( 'Email', 'gocargo-shipment' ),
                'id'   => 'receiver_email',
                'type' => 'text',
                'tab'  => 'receiver',
            ),

            // Shipment information
            array(
                'name' => esc_html__( 'Weight', 'gocargo-shipment' ),
                'id'   => 'shipment_weight',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Courier', 'gocargo-shipment' ),
                'id'   => 'shipment_courier',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Packages', 'gocargo-shipment' ),
                'id'   => 'shipment_packages',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Mode', 'gocargo-shipment' ),
                'id'   => 'shipment_mode',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Product', 'gocargo-shipment' ),
                'id'   => 'shipment_product',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Quantity', 'gocargo-shipment' ),
                'id'   => 'shipment_quantity',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Payment Mode', 'gocargo-shipment' ),
                'id'   => 'shipment_payment_mode',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Total Freight', 'gocargo-shipment' ),
                'id'   => 'shipment_total_freight',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Carrier', 'gocargo-shipment' ),
                'id'   => 'shipment_carrier',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Carrier Reference Number', 'gocargo-shipment' ),
                'id'   => 'shipment_carrier_reference_number',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Departure Time', 'gocargo-shipment' ),
                'id'   => 'shipment_departure_time',
                'type' => 'text',
                'type' => 'time',
                'format ' => 'hh:mm',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Origin', 'gocargo-shipment' ),
                'id'   => 'shipment_origin',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Destination', 'gocargo-shipment' ),
                'id'   => 'shipment_destination',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Pickup Date', 'gocargo-shipment' ),
                'id'   => 'shipment_pickup_date',
                'type' => 'date',
                'format' => 'mm dd, yy',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Pickup Time', 'gocargo-shipment' ),
                'id'   => 'shipment_pickup_time',
                'type' => 'time',
                'format ' => 'hh:mm',
                'tab'  => 'shipment',
            ),
            array(
                'name'        => esc_html__( 'Select Status', 'gocargo-shipment' ),
                'id'          => "shipment_status",
                'type'        => 'select',
                // Array of 'value' => 'Label' pairs for select box
                'options'     => array(
                    'accepted' => esc_html__( 'Accepted', 'gocargo-shipment' ),
                    'processing' => esc_html__( 'Processing', 'gocargo-shipment' ),
                    'pending' => esc_html__( 'Pending', 'gocargo-shipment' ),
                    'delived' => esc_html__( 'Delived', 'gocargo-shipment' ),
                ),
                // Select multiple values, optional. Default is false.
                'multiple'    => false,
                'std'         => 'accepted',
                //'placeholder' => esc_html__( 'Select Shipment Status', 'gocargo-shipment' ),
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Expected Delivery Date', 'gocargo-shipment' ),
                'id'   => 'shipment_expected_delivery_date',
                'type' => 'date',
                'format' => 'mm dd, yy',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Comments', 'gocargo-shipment' ),
                'id'   => 'shipment_comments',
                'type' => 'textarea',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Agent Name', 'gocargo-shipment' ),
                'id'   => 'shipment_agent_name',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
            array(
                'name' => esc_html__( 'Type of Shipment', 'gocargo-shipment' ),
                'id'   => 'shipment_type_of_shipment',
                'type' => 'text',
                'tab'  => 'shipment',
            ),
        ),
    );

    return $meta_boxes;
}
add_filter( 'rwmb_meta_boxes', 'gocargo_shipment_register_meta_boxes' );