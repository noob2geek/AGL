<?php
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
/*------------------------------Admin Column Filter------------------------------*/

add_filter('parse_query', 'gocargo_posts_status_filter');
function gocargo_posts_status_filter($query) {

    if (isset($_GET['post_type']) != 'gocargo_shipment')
	return;

    global $pagenow;

    if (is_admin() && $pagenow == 'edit.php' && isset($_GET['ADMIN_FILTER_FIELD_NAME']) && $_GET['ADMIN_FILTER_FIELD_NAME'] != '') {
        $query->query_vars['meta_key'] = $_GET['ADMIN_FILTER_FIELD_NAME'];
        if (isset($_GET['ADMIN_FILTER_FIELD_VALUE']) && $_GET['ADMIN_FILTER_FIELD_VALUE'] != '')
            $query->query_vars['meta_value'] = $_GET['ADMIN_FILTER_FIELD_VALUE'];
    }
}

add_action('restrict_manage_posts', 'gocargo_filter_restrict_manage_posts');
function gocargo_filter_restrict_manage_posts() {
    global $wpdb, $typenow;
    $sql    = 'SELECT DISTINCT meta_key FROM ' . $wpdb->postmeta . ' ORDER BY 1';
    $fields = $wpdb->get_results($sql, ARRAY_N);
	$post_type = 'gocargo_shipment'; // change to your post type
    $taxonomy  = 'gocargo_shipment_cate'; // change to your taxonomy
    if ($typenow == $post_type) {

?>
    <input name="ADMIN_FILTER_FIELD_NAME" type="hidden" value="shipment_status">
    <select name="ADMIN_FILTER_FIELD_VALUE">
    	<option value=""><?php esc_attr_e('All Shipment Status', 'gocargo-shipment'); ?></option>
        <option value="accepted" <?php if(isset($_GET['ADMIN_FILTER_FIELD_VALUE'])){ selected(($_GET['ADMIN_FILTER_FIELD_VALUE']), sanitize_text_field('accepted')); }?> ><?php _e('Accepted', 'gocargo-shipment'); ?></option>
        <option value="processing" <?php if(isset($_GET['ADMIN_FILTER_FIELD_VALUE'])){ selected(($_GET['ADMIN_FILTER_FIELD_VALUE']), sanitize_text_field('processing')); }?> ><?php _e('Processing', 'gocargo-shipment'); ?></option>
        <option value="pending" <?php if(isset($_GET['ADMIN_FILTER_FIELD_VALUE'])){ selected(($_GET['ADMIN_FILTER_FIELD_VALUE']), sanitize_text_field('pending')); }?> ><?php _e('Pending', 'gocargo-shipment'); ?></option>
        <option value="delived" <?php if(isset($_GET['ADMIN_FILTER_FIELD_VALUE'])){ selected(($_GET['ADMIN_FILTER_FIELD_VALUE']), sanitize_text_field('delived')); }?> ><?php _e('Delived', 'gocargo-shipment'); ?></option>
    </select>
<?php
	}
}

/**
 * Display a custom taxonomy dropdown in admin
 */
add_action('restrict_manage_posts', 'gocargo_shipment_filter_post_type_by_taxonomy');
function gocargo_shipment_filter_post_type_by_taxonomy() {
    global $typenow;
    $post_type = 'gocargo_shipment'; // change to your post type
    $taxonomy  = 'gocargo_shipment_cate'; // change to your taxonomy
    if ($typenow == $post_type) {
        $selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
        $info_taxonomy = get_taxonomy($taxonomy);
        wp_dropdown_categories(array(
            'show_option_all' => __("Show All {$info_taxonomy->label}"),
            'taxonomy'        => $taxonomy,
            'name'            => $taxonomy,
            'orderby'         => 'name',
            'selected'        => $selected,
            'show_count'      => true,
            'hide_empty'      => true,
        ));
    };
}

/**
 * Filter posts by taxonomy in admin
 */
add_filter('parse_query', 'gocargo_shipment_convert_id_to_term_in_query');
function gocargo_shipment_convert_id_to_term_in_query($query) {
    global $pagenow;
    $post_type = 'gocargo_shipment'; // change to your post type
    $taxonomy  = 'gocargo_shipment_cate'; // change to your taxonomy
    $q_vars    = &$query->query_vars;
    if ( $pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
        $term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
        $q_vars[$taxonomy] = $term->slug;
    }
}

/**
* Admin custom post type columns
*/
// Add to admin_init function
add_filter('manage_edit-gocargo_shipment_columns', 'add_new_gocargo_shipment_columns');
function add_new_gocargo_shipment_columns($gocargo_shipment_columns) {
    $new_columns['cb'] = '<input type="checkbox" />';     
    $new_columns['title'] = _x('Consignment No.', 'gocargo-shipment');
    $new_columns['author'] = _x('Author', 'gocargo-shipment');
    $new_columns['gocargo_shipment_cate'] = _x('Shipment Category', 'gocargo-shipment');
    $new_columns['gocargo_shipment_tags'] = _x('Shipment Tags', 'gocargo-shipment');
    $new_columns['shipment_status'] = _x('Status', 'gocargo-shipment');
    $new_columns['date'] = _x('Date', 'gocargo-shipment');

    return $new_columns;
}

// Add to admin_init function
add_action('manage_gocargo_shipment_posts_custom_column', 'manage_gocargo_shipment_columns', 10, 2);
function manage_gocargo_shipment_columns($column, $post_id) {
    global $wpdb;
    switch ($column) {
        case 'shipment_status':
            $ship_status = get_post_meta($post_id, 'shipment_status', true);
            if (empty($ship_status))
                _e('No Status', 'gocargo-shipment');
            else {
                echo $ship_status;
            }
            break;
        case 'gocargo_shipment_cate':
            $terms = get_the_terms($post_id, 'gocargo_shipment_cate');
            if (!empty($terms)) {
                $out = array();
                foreach ($terms as $term) {
                    $out[] = sprintf('<a href="%s">%s</a>', esc_url(add_query_arg(array(
                        'post_type' => $post->post_type,
                        'gocargo_shipment_cate' => $term->slug
                    ), 'edit.php')), esc_html(sanitize_term_field('name', $term->name, $term->term_id, 'gocargo_shipment_cate', 'display')));
                }
                echo join(', ', $out);
            } else {
                _e('No Shipment Category', 'gocargo-shipment');
            }
            break;
        case 'gocargo_shipment_tags':
            $terms = get_the_terms($post_id, 'gocargo_shipment_tags');
            if (!empty($terms)) {
                $out = array();
                foreach ($terms as $term) {
                    $out[] = sprintf('<a href="%s">%s</a>', esc_url(add_query_arg(array(
                        'post_type' => $post->post_type,
                        'gocargo_shipment_tags' => $term->slug
                    ), 'edit.php')), esc_html(sanitize_term_field('name', $term->name, $term->term_id, 'gocargo_shipment_tags', 'display')));
                }
                echo join(', ', $out);
            } else {
                _e('No Shipment Tag', 'gocargo-shipment');
            }
            break;    
        default:
            break;
    } // end switch
}   

// Shortcode Form Search
function trucking_search(){
    ob_start();
?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div id="search-container" data-wow-duration="1s" data-wow-delay="0s" class="cta-form wow fadeIn">
                    <form role="search" method="POST" id="searchform" name="trackform" >
                        <input type="text" value="" name="s" id="s" placeholder="<?php esc_attr_e('Insert tracking number here...', 'gocargo-shipment'); ?>">
                        <input type="submit" onclick="return IsEmpty();" value="<?php esc_attr_e('TRACK IT', 'gocargo-shipment'); ?>" name="submit"> 
						<img class="ajax-loader" src="<?php echo plugins_url( 'assets/images/loader.gif', __FILE__ ) ?>" alt="Sending ...">
                        <input type="hidden" name="post_type" value="gocargo_shipment" /> 
                    </form>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="light-text" id="section-tracking-result"></div>

<?php 
    return ob_get_clean();
}
add_shortcode('trucking_search', 'trucking_search');

// Shortcode Form Search 2
function trucking_search2(){
    ob_start();
?>
    
    <div class="container">
        <div class="row">
            <form role="search" method="POST" id="searchform" name="trackform">
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-7 no-padding">
                            <div class="inner">
                                <h3><?php esc_attr_e('Track &amp; Trace', 'gocargo-shipment'); ?></h3>
                                <span><?php esc_attr_e('Already have a load ID, please insert it below', 'gocargo-shipment'); ?></span>
                            </div>
                        </div>
                        <div class="col-md-5 no-padding">
                            <input class="input-fullwidth" type="text" value="" name="s" id="s">
                        </div>
                    </div>
                </div>                  
                <div class="col-md-3">
                    <input class="btn-custom btn-fullwidth" type="submit" onclick="return IsEmpty();" value="<?php esc_attr_e('TRACK IT', 'gocargo-shipment'); ?>" name="submit">
					<img class="ajax-loader" src="<?php echo plugins_url( 'assets/images/loader.gif', __FILE__ ) ?>" alt="Sending ...">
                </div>
                <input type="hidden" name="post_type" value="gocargo_shipment" /> 
            </form>
            <div class="clearfix"></div>
        </div>
    </div>

<?php 
    return ob_get_clean();
}
add_shortcode('trucking_search2', 'trucking_search2');

function wpa56343_search() {
    if ( ! isset( $_POST['search'] ) )
        exit;

    query_posts(
        array(
            'posts_per_page' => 1,
            'no_found_rows' => true,
            'post_type' => 'gocargo_shipment',
            's' => wp_unslash( ( string ) $_POST['search'] ),
        )
    );

    if ( $overridden_template = locate_template( 'search-gocargo_shipment.php' ) ) {
       // locate_template() returns path to file
       // if either the child theme or the parent theme have overridden the template
       load_template( $overridden_template );
     } else {
       // If neither the child nor parent theme have overridden the template,
       // we load the template from the 'templates' sub-directory of the directory this file is in
       load_template( GOCARGOSHIPMENT_PATH . '/templates/search-gocargo_shipment.php' );
     }

    //get_template_part( 'search-gocargo_shipment' );

    exit;
}
add_action( 'wp_ajax_nopriv_wpa56343_search', 'wpa56343_search', 100 );
add_action( 'wp_ajax_wpa56343_search',        'wpa56343_search', 100 );

if(!function_exists('gocargo_custom_frontend_ajaxsearch')){
    function gocargo_custom_frontend_ajaxsearch(){
        ?>
            <script type="text/javascript">	
				function IsEmpty(){
					if(document.forms['trackform'].s.value === ""){
						alert("fields is empty, please enter your tracking code.");
						return false;
					}
					return true;
				}	
                jQuery( document ).ready(function ($) {					
                    $( "#searchform" ).on( "submit", function (ev) {
                        ev.preventDefault();
						var $form = jQuery(this);
                        var $input = $form.find('input[name="s"]');
						var $content = jQuery('.ajax-loader')
                        $.post({
                            url: '<?php echo admin_url('admin-ajax.php'); ?>',
							type: 'post',
                            data: {
                                action: "wpa56343_search",
                                search: $( "#s" ).val()
                            },
							beforeSend: function() {
								$input.prop('disabled', true);
								$content.addClass('loading');
							},
                            success: function ( data ) {
								$input.prop('disabled', false);								
								$content.removeClass('loading');
								$('#section-tracking-result').html(data);								
                            }							
                        });            
                        return false;            
                    });
                });						
            </script>
        <?php        
    }
}
add_action('wp_footer', 'gocargo_custom_frontend_ajaxsearch');