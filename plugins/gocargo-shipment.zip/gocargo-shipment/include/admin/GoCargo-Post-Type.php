<?php
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/*------------------------------GoCargo Post Type------------------------------*/

add_action( 'init', 'gocargo_shipment_init' );
/**
 * Register a gocargo_shipment post type.
 */
function gocargo_shipment_init() {
	$labels = array(
		'name'               => __( 'Shipment', 'post type general name', 'gocargo-shipment' ),
		'singular_name'      => __( 'Shipment', 'post type singular name', 'gocargo-shipment' ),
		'menu_name'          => __( 'GOCargo Shipment', 'admin menu', 'gocargo-shipment' ),
		'name_admin_bar'     => __( 'Shipment', 'add new on admin bar', 'gocargo-shipment' ),
		'add_new'            => __( 'Add Shipment', 'gocargo_shipment', 'gocargo-shipment' ),
		'add_new_item'       => __( 'Add New Shipment', 'gocargo-shipment' ),
		'new_item'           => __( 'New Shipment', 'gocargo-shipment' ),
		'edit_item'          => __( 'Edit Shipment', 'gocargo-shipment' ),
		'view_item'          => __( 'View Shipment', 'gocargo-shipment' ),
		'all_items'          => __( 'All Shipment', 'gocargo-shipment' ),
		'search_items'       => __( 'Search Shipment', 'gocargo-shipment' ),
		'parent_item_colon'  => __( 'Parent Shipment:', 'gocargo-shipment' ),
		'not_found'          => __( 'No shipment found.', 'gocargo-shipment' ),
		'not_found_in_trash' => __( 'No shipment found in Trash.', 'gocargo-shipment' )
	);

	$args = array(
		'labels'             => $labels,
        'description'        => __( 'Description.', 'gocargo-shipment' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'gocargo_shipment' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'menu_icon' => 'dashicons-location-alt',
		'supports'           => array( 'title', 'author', 'thumbnail' ),		
	);

	register_post_type( 'gocargo_shipment', $args );
}

// hook into the init action and call gocargo_shipment_taxonomies when it fires
add_action( 'init', 'gocargo_shipment_taxonomies', 0 );

// create two taxonomies, genres and writers for the post type "gocargo_shipment"
function gocargo_shipment_taxonomies() {
	// Add new taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'              => __( 'Shipment Categories', 'taxonomy general name' ),
		'singular_name'     => __( 'Shipment Category', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Shipment Categories' ),
		'all_items'         => __( 'All Shipment Categories' ),
		'parent_item'       => __( 'Parent Shipment Category' ),
		'parent_item_colon' => __( 'Parent Shipment Category:' ),
		'edit_item'         => __( 'Edit Shipment Category' ),
		'update_item'       => __( 'Update Shipment Category' ),
		'add_new_item'      => __( 'Add New Shipment Category' ),
		'new_item_name'     => __( 'New Shipment Category Name' ),
		'menu_name'         => __( 'Shipment Category' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'gocargo_shipment_cate' ),
	);

	register_taxonomy( 'gocargo_shipment_cate', array( 'gocargo_shipment' ), $args );

	// Add new taxonomy, NOT hierarchical (like tags)
	$labels = array(
		'name'                       => __( 'Tags', 'taxonomy general name' ),
		'singular_name'              => __( 'Tag', 'taxonomy singular name' ),
		'search_items'               => __( 'Search Tags' ),
		'popular_items'              => __( 'Popular Tags' ),
		'all_items'                  => __( 'All Tags' ),
		'parent_item'                => null,
		'parent_item_colon'          => null,
		'edit_item'                  => __( 'Edit Tag' ),
		'update_item'                => __( 'Update Tag' ),
		'add_new_item'               => __( 'Add New Tag' ),
		'new_item_name'              => __( 'New Tag Name' ),
		'separate_items_with_commas' => __( 'Separate tags with commas' ),
		'add_or_remove_items'        => __( 'Add or remove tags' ),
		'choose_from_most_used'      => __( 'Choose from the most used tags' ),
		'not_found'                  => __( 'No tags found.' ),
		'menu_name'                  => __( 'Shipment Tags' ),
	);

	$args = array(
		'hierarchical'          => false,
		'labels'                => $labels,
		'show_ui'               => true,
		'show_admin_column'     => true,
		'update_count_callback' => '_update_post_term_count',
		'query_var'             => true,
		'rewrite'               => array( 'slug' => 'gocargo_shipment_tags' ),
	);

	register_taxonomy( 'gocargo_shipment_tags', 'gocargo_shipment', $args );
}