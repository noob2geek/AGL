<?php  if ( have_posts() ) : while ( have_posts() ) : the_post(); ?> 
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="divider-double"></div>
            <div class="text-center">
                <h3><span class="grey"><?php esc_html_e('Product ID:', 'gocargo-shipment'); ?></span> <?php the_title(); ?></h3>
            </div>
            <div class="divider-double"></div>
            <div class="wrapper-line padding40 rounded10">
                <ul class="progress">
                <?php if( function_exists( 'rwmb_meta' ) ) { ?>
                    <?php 
                        $shipment_status = get_post_meta(get_the_ID(),'shipment_status', true);
                        $shipment_status_before = '';
                        $shipment_status_after = '';
                        switch ($shipment_status) {
                            case 'processing':
                                $shipment_status_before = '<li class="beforeactive">' . esc_attr_x('Accepted', 'gocargo-shipment') . '</li>
                                    <li class="active">' . esc_attr_x('Order Processing', 'gocargo-shipment') . '</li>
                                    <li>' . esc_attr_x('Shipment Pending', 'gocargo-shipment') . '</li>
                                    <li>' . esc_attr_x('Estimated Delivery', 'gocargo-shipment') . '</li>';
                                break;                                                
                            case 'pending':
                                $shipment_status_before = '<li>' . esc_attr_x('Accepted', 'gocargo-shipment') . '</li>
                                    <li class="beforeactive">' . esc_attr_x('Order Processing', 'gocargo-shipment') . '</li>
                                    <li class="active">' . esc_attr_x('Shipment Pending', 'gocargo-shipment') . '</li>
                                    <li>' . esc_attr_x('Estimated Delivery', 'gocargo-shipment') . '</li>';
                                break;
                            case 'delived':
                                $shipment_status_before = '<li>' . esc_attr_x('Accepted', 'gocargo-shipment') . '</li>
                                    <li>' . esc_attr_x('Order Processing', 'gocargo-shipment') . '</li>
                                    <li class="beforeactive">' . esc_attr_x('Shipment Pending', 'gocargo-shipment') . '</li>
                                    <li class="active">' . esc_attr_x('Estimated Delivery', 'gocargo-shipment') . '</li>';
                                break;        
                            default:
                                $shipment_status_before = '<li class="active">' . esc_attr_x('Accepted', 'gocargo-shipment') . '</li>
                                    <li>' . esc_attr_x('Order Processing', 'gocargo-shipment') . '</li>
                                    <li>' . esc_attr_x('Shipment Pending', 'gocargo-shipment') . '</li>
                                    <li>' . esc_attr_x('Estimated Delivery', 'gocargo-shipment') . '</li>';
                            }
                            
                            echo $shipment_status_before;        
                    ?>                            
                <?php } ?>
                </ul>

                <div class="divider-double"></div>

                <ul class="timeline custom-tl">
                    <?php if( function_exists( 'rwmb_meta' ) ) { ?>
                        <?php 
                            $group_values = rwmb_meta( 'standard' );
                            if ( ! empty( $group_values ) )
                            {
                                foreach ( $group_values as $group_value )
                                {
                                    $history_time = isset( $group_value['history_time'] ) ? $group_value['history_time'] : '';
                                    $history_date = isset( $group_value['history_date'] ) ? $group_value['history_date'] : '';
                                    $history_status = isset( $group_value['history_status'] ) ? $group_value['history_status'] : '';
                                    $history_remarks = isset( $group_value['history_remarks'] ) ? $group_value['history_remarks'] : '';
                                    $address = isset( $group_value['address'] ) ? $group_value['address'] : '';
                                    $location = isset( $group_value['location'] ) ? $group_value['location'] : '';
                                    $class_icon = '';  
                                    $class_badge = '';                                           
                                    switch ($history_status) {
                                        case 'info_received':
                                            $class_icon = 'fa fa-file-text-o';
                                            $class_badge = 'inforeceived';
                                            break;
                                        case 'in_transit':
                                            $class_icon = 'fa fa-truck';
                                            $class_badge = 'intransit';
                                            break;
                                        case 'out_for_delivery':
                                            $class_icon = 'fa fa-cube';
                                            $class_badge = 'outfordelivery';
                                            break;
                                        case 'delivered':
                                            $class_icon = 'fa fa-check-square-o';
                                            $class_badge = 'success';
                                            break;
                                        case 'failed_attempt':
                                            $class_icon = 'fa fa-bolt';
                                            $class_badge = 'attemptfail';
                                            break;
                                        case 'exception':
                                            $class_icon = 'fa fa-exclamation-triangle';
                                            $class_badge = 'warning';
                                            break;
                                        case 'expired':
                                            $class_icon = 'fa fa-clock-o';
                                            $class_badge = 'expired';
                                            break;
                                        case 'pending':
                                            $class_icon = 'fa fa-refresh';
                                            $class_badge = 'pending';
                                            break;
                                        case 'trucking':
                                            $class_icon = 'fa fa-truck';
                                            $class_badge = 'primary';
                                            break;
                                        case 'air_freight':
                                            $class_icon = 'fa fa-plane';
                                            $class_badge = '';
                                            break;
                                        case 'ocean_freight':
                                            $class_icon = 'fa fa-ship';
                                            $class_badge = 'primary';
                                            break;        
                                        default:
                                            $class_icon = 'fa fa-refresh';
                                            $class_badge = 'pending';
                                    }                                                                                                                              

                        ?>
                                    <li class="timeline-inverted">
                                        <div data-wow-delay=".2s" class="timeline-date wow zoomIn">
                                            <?php echo esc_attr($history_date); ?>
                                            <span><?php echo esc_attr($history_time); ?></span>
                                        </div>
                                        <div class="timeline-badge <?php echo esc_attr($class_badge); ?>">
                                            <i class="<?php echo esc_attr($class_icon); ?> wow zoomIn"></i>
                                        </div>
                                        <div data-wow-delay=".6s" class="timeline-panel wow fadeInRight">
                                            <div class="timeline-body">
                                                <?php echo esc_attr($history_remarks); ?>
                                                <span class="location"><?php echo esc_attr($address); ?> 
                                                    <a class="popup-gmaps" href="<?php echo esc_url($location); ?>">view on map</a>
                                                </span>
                                            </div>
                                        </div>
                                    </li>
                        <?php                                             
                                }
                            } 
                        ?>
                    <?php } ?>    
                </ul>
            </div>
        </div>
    </div>
</div>
<?php endwhile; ?>

<?php else : ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
			<p>This tracking number cannot be found, please check the number or contact the sender.</p>
		</div>
	</div>
</div>	
<?php endif; ?>


