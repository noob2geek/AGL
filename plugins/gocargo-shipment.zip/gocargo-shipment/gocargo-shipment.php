<?php
/*
Plugin Name: GoCargo Shipment
Plugin URI:  http://oceanthemes.net/
Description: Gocargo Shipment is a WordPress plug-in designed to provide ideal technology solution for your Cargo and Courier Operations.
Version:     1.0.1
Author:      Davis Hoang
Author URI:  http://oceanthemes.net/
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Domain Path: /languages
Text Domain: gocargo-shipment
*/

//definitions
if(!defined('GOCARGOSHIPMENT_PATH')) define( 'GOCARGOSHIPMENT_PATH', plugin_dir_path(__FILE__) );
if(!defined('GOCARGOSHIPMENT_DIR')) define( 'GOCARGOSHIPMENT_DIR', plugin_dir_url(__FILE__) );

function GOCARGOSHIPMENT_localisation() {
	load_plugin_textdomain( 'gocargo-shipment', FALSE, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action('init', 'GOCARGOSHIPMENT_localisation');

//required functions & classes
require_once(GOCARGOSHIPMENT_PATH . 'include/admin/GoCargo-Post-Type.php');
require_once(GOCARGOSHIPMENT_PATH . 'include/admin/GoCargo-Filter.php');
require_once(GOCARGOSHIPMENT_PATH . 'include/admin/GoCargo-Meta-Box.php');

?>