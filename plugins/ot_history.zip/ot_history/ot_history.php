<?php
/*
	Plugin Name: OT History
	Plugin URI: http://oceanthemes.net/
	Description: Declares a plugin that will create a custom post type displaying portfolio.
	Version: 1.0
	Author: OceanThemes Team
	Author URI: http://oceanthemes.net/
	Text Domain: ot_history
	Domain Path: /lang
	License: GPLv2 or later
*/

/* UPDATE 
  register_activation_hook is not called when a plugin is updated
  so we need to use the following function 
*/
function ot_history_update() {
	load_plugin_textdomain('ot_history', FALSE, dirname(plugin_basename(__FILE__)) . '/lang/');
}
add_action('plugins_loaded', 'ot_history_update');

function ot_historys_type() {
	$Historylabels = array (	

		'name' => __('History','ot_history'),

		'singular_name' => __('History','ot_history'),

		'add_new' => __('Add History','ot_history'),

		'add_new_item' => __('Add new History','ot_history'),

		'edit_item' => __('Edit History','ot_history'),

		'new_item' => __('Add new History','ot_history'),

		'all_items' => __('All History','ot_history'),

		'view_item' => __('View History','ot_history'),

		'search_item' => __('Search History','ot_history'),

		'not_found' => __('No History found..','ot_history'),

		'not_found_in_trash' => __('No History found in Trash.','ot_history'),

		'menu_name' => 'History'
	);

	$args = array(
		'labels' => $Historylabels,
		'hierarchical' => false,
		'description' => 'Manages History',
		'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => null,
		'menu_icon' => 'dashicons-chart-pie',		
		'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array('slug'=>'history'),
        'capability_type' => 'post',
		'supports' => array( 'title','editor','thumbnail','excerpt','comments','custom-fields'),
	);
	register_post_type ('history',$args);
}
add_action ('init','ot_historys_type');

function ot_history_taxonomy () {
	$taxonomylabels = array(

	'name' => __('Category History','ot_history'),

	'singular_name' => __('Category History','ot_history'),

	'search_items' => __('Search Category History','ot_history'),

	'all_items' => __('All Category History','ot_history'),

	'edit_item' => __('Edit Category History','ot_history'),

	'add_new_item' => __('Add new Category History','ot_history'),

	'menu_name' => __('Category History','ot_history'),

	);

	$args = array(

	'labels' => $taxonomylabels,

	'hierarchical' => true,

);
	register_taxonomy('category_history','history',$args);
}
add_action ('init','ot_history_taxonomy',0);

?>