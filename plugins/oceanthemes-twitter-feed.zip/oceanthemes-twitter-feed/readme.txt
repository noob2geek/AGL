=== Plugin Name ===
http://test.wiloke.com/wp-content/uploads/2015/03/wiloke-twitter-feed.zip
Contributors: wiloke
Tags: widget, twitter, feed
Requires at least: 3.9
Tested up to:  4.1.1
Stable tag:  4.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add twitter feeds on your WordPress site

== Description ==

<p>Display Tweets  in a sidebar easily.</p>

<h3><strong>Key Features & Options</strong></h3>
<ul>
<li>Easy Twitter Feed Widget Plugin is very easy to setup and use.</li>
<li>Custom link color</li>
<li>Cache</li>
</ul>


<h3><strong>Question & Supports</strong></h3>
You want more features on next release? Please  contact us <a href="mail:piratesmorefun@gmail.com">piratesmorefun@gmail.com</a>

== Installation ==

You can use the built in installer and upgrader, or you can install the plugin manually.
1. Go to the menu 'Plugins' -> 'Install' and search for 'Wiloke Twitter Feed'
2. Click 'install'.
3. Go "Widgets" from "Appearance" menu. (N.B.: Must be support widget in your theme.)
4. Drag it in theme's widget area and set it up as your setting.

== Frequently Asked Questions ==

= Features Request & Support =
Please  contact us <a href="mail:piratesmorefun@gmail.com">piratesmorefun@gmail.com</a>


== Screenshots ==
1. screenshot-1.png 
2. screenshot-2.png 
3. screenshot-3.png 
4. screenshot-4.png 

== Changelog ==

= 1.0 =
* Released

== Upgrade Notice ==
Just upgrade via Wordpress.
