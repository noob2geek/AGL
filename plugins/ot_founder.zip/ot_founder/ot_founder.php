<?php
/*
	Plugin Name: OT Founder
	Plugin URI: http://oceanthemes.net/
	Description: Declares a plugin that will create a custom post type displaying portfolio.
	Version: 1.0
	Author: OceanThemes Team
	Author URI: http://oceanthemes.net/
	Text Domain: ot_founder
	Domain Path: /lang
	License: GPLv2 or later
*/

/* UPDATE 
  register_activation_hook is not called when a plugin is updated
  so we need to use the following function 
*/
function ot_founder_update() {
	load_plugin_textdomain('ot_founder', FALSE, dirname(plugin_basename(__FILE__)) . '/lang/');
}
add_action('plugins_loaded', 'ot_founder_update');

function ot_founders_type() {
	$Founderlabels = array (	

		'name' => __('Founder','ot_founder'),

		'singular_name' => __('Founder','ot_founder'),

		'add_new' => __('Add Founder','ot_founder'),

		'add_new_item' => __('Add new Founder','ot_founder'),

		'edit_item' => __('Edit Founder','ot_founder'),

		'new_item' => __('Add new Founder','ot_founder'),

		'all_items' => __('All Founder','ot_founder'),

		'view_item' => __('View Founder','ot_founder'),

		'search_item' => __('Search Founder','ot_founder'),

		'not_found' => __('No Founder found..','ot_founder'),

		'not_found_in_trash' => __('No Founder found in Trash.','ot_founder'),

		'menu_name' => 'Founder'
	);

	$args = array(
		'labels' => $Founderlabels,
		'hierarchical' => false,
		'description' => 'Manages Founder',
		'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => null,
		'menu_icon' => 'dashicons-businessman',		
		'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array('slug'=>'Founder'),
        'capability_type' => 'post',
		'supports' => array( 'title','editor','thumbnail','excerpt','comments','custom-fields'),
	);
	register_post_type ('founder',$args);
}
add_action ('init','ot_founders_type');

function ot_founder_taxonomy () {
	$taxonomylabels = array(

	'name' => __('Category Founder','ot_founder'),

	'singular_name' => __('Category Founder','ot_founder'),

	'search_items' => __('Search Category Founder','ot_founder'),

	'all_items' => __('All Category Founder','ot_founder'),

	'edit_item' => __('Edit Category Founder','ot_founder'),

	'add_new_item' => __('Add new Category Founder','ot_founder'),

	'menu_name' => __('Category Founder','ot_founder'),

	);

	$args = array(

	'labels' => $taxonomylabels,

	'hierarchical' => true,

);
	register_taxonomy('category_founder','founder',$args);
}
add_action ('init','ot_founder_taxonomy',0);

?>